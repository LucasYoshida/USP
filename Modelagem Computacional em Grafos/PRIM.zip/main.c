/*
***************************************************

	USP - ICMC
	Modelagem Computacional em Grafos - SCC0216 - 2018
	
	Grafos em Lista e Matriz de Adjacência

	Lucas Noriyuki Yoshida - 10262586

****************************************************
*/

#include <stdio.h>
#include <stdlib.h>
#include "lista.h"
#include "fila.h"

int main (){

	grafo_l* g1;			//grafo referente a lista de adjacencia

	int aresta, vertice;	//guarda o numero de arestas e vertices

	int** arestas;			//guarda quais são as arestas (origem/destino e peso)

	char* entrada;			//guarda a entrada (D = digrafo, G = grafo, M = matriz de adjacencia, L = lista de adjacencia)

	char e1;				//e1 ('D' = digrafo, 'G', grafo)

	int digrafo = 0;		//indica se e' um digrafo ou nao (1 = sim, 0 = nao)

//********************************************************

	//no caso sempre eh digrafo
	e1 = 'D';

	//alocação na heap
	//op = (char*)calloc(2, sizeof(char));
	entrada = (char*)calloc(8, sizeof(char));

	scanf("%d %d", &vertice, &aresta);

	g1 = (grafo_l*)calloc(vertice, sizeof(grafo_l));

	if(e1 == 'D')		//verifica se e' digrafo
		digrafo = 0;

	//alocacao das informacoes das aresta (origem/destino/peso)
	arestas = (int**)calloc(1000, sizeof(int*));
	for(int cont = 0; cont < 1000; cont++){
		arestas[cont] = (int*)calloc(3, sizeof(int));
	}

	//entrada das informacoes das arestas
	for(int cont = 0; cont < aresta; cont++){
		scanf("%d %d %d", &arestas[cont][0], &arestas[cont][1], &arestas[cont][2]);
	}

//********************************************************

	//cria a lista de adjacencia
	cria_grafo_l(g1, vertice);

	preenche_inicial_l(g1, aresta, arestas, digrafo);

	algPrim(g1, vertice);

	destroi_lista(g1, vertice);

//********************************************************

	//free
	free(entrada);
	for(int cont = 0; cont < 3; cont++)
		free(arestas[cont]);
	free(arestas);
	free(g1);

	return 0;

}
