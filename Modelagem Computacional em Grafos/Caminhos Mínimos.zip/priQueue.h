/*
***************************************************

	USP - ICMC
	Modelagem Computacional em Grafos - SCC0216 - 2018
	
	TAD fila prioritaria

	Lucas Noriyuki Yoshida - 10262586

****************************************************
*/

typedef struct{

	int source, destiny, weight;	

} edge;

typedef struct priQueue priQueue_t;

priQueue_t* creatPriQueue();
unsigned char emptyPriQueue(priQueue_t *f);
void insertPriQueue(priQueue_t *f, edge *a);
void updatePriQueue(priQueue_t *f, int source, int destiny);
edge removePriQueue(priQueue_t *f);
void showPriQueue(priQueue_t *f);
void liberatePriQueue(priQueue_t *f);