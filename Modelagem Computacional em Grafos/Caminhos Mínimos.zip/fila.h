/*
***************************************************

	USP - ICMC
	Modelagem Computacional em Grafos - SCC0216 - 2018
	
	TAD Fila para busca

	Lucas Noriyuki Yoshida - 10262586

****************************************************
*/

#include <stdio.h>
#include <stdlib.h>

#define TamFila 100

typedef struct fila{
	
	int inicio, fim, total;
	int itens[TamFila];

} Fila;

Fila* cria_fila(int *flagErro);

void esvazia_fila(Fila *F , int *flagErro);

void destroi_fila(Fila *F, int *flagErro);

int fila_vazia(Fila *F,int *flagErro);

int fila_cheia(Fila *F,int *flagErro);

int tamanho_fila(Fila *F,int *flagErro);

void insere_fila(Fila *F, int X, int *erro);

void remove_fila(Fila *F, int *X, int *erro);