/*
***************************************************

	USP - ICMC
	Modelagem Computacional em Grafos - SCC0216 - 2018
	
	Grafos em Lista e Matriz de Adjacência

	Lucas Noriyuki Yoshida - 10262586

****************************************************
*/

#include <stdio.h>
#include <stdlib.h>
#include "lista.h"
#include "fila.h"
#include "priQueue.h"

int main (){

	grafo_l* g1;			//grafo referente a lista de adjacencia

	int aresta, vertice;	//guarda o numero de arestas e vertices

	char* entrada;			//guarda a entrada (D = digrafo, G = grafo, M = matriz de adjacencia, L = lista de adjacencia)

	char e1;				//e1 ('D' = digrafo, 'G', grafo)

	int digrafo = 0;		//indica se e' um digrafo ou nao (1 = sim, 0 = nao)

	int origem, destino, peso;

//********************************************************

	//no caso sempre eh digrafo
	e1 = 'D';

	//alocação na heap
	//op = (char*)calloc(2, sizeof(char));
	entrada = (char*)calloc(8, sizeof(char));

	scanf("%d %d", &vertice, &aresta);

	g1 = (grafo_l*)calloc(vertice, sizeof(grafo_l));

	if(e1 == 'D')		//verifica se e' digrafo
		digrafo = 1;

	cria_grafo_l(g1, vertice);

	//entrada das informacoes das arestas
	for(int cont = 0; cont < aresta; cont++){
		scanf("%d %d %d", &origem, &destino, &peso);
		cria_aresta_la(g1, origem, destino, peso, digrafo);
	}

	// imprime_grafo_l(g1, vertice);

//********************************************************

	while(scanf("%d %d", &origem, &destino) != EOF){
		// printf("%d %d\n", origem, destino);
		dijkstra1(g1, origem, destino, vertice, aresta);
		// printf("----------------------------------------------\n");
	}

	destroi_lista(g1, vertice);

//********************************************************

	//free
	free(entrada);
	free(g1);

	return 0;

}
