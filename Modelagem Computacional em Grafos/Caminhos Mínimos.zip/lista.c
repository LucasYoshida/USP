/*
***************************************************

	USP - ICMC
	Modelagem Computacional em Grafos - SCC0216 - 2018
	
	Grafos em Lista de Adjacência

	Lucas Noriyuki Yoshida - 10262586

****************************************************
*/

#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include "lista.h"
#include "fila.h"
#include "priQueue.h"

/*Funcao que cria um grafo por lista de adjacencia
grafo_l* g = grafo
int n = numero de vertices
*/
void cria_grafo_l(grafo_l* g, int n){

	for(int cont = 0; cont < n; cont++){
		g[cont].list = (node*)calloc(1, sizeof(node));
		g[cont].list->next = NULL;
		g[cont].list->info = -1;
		g[cont].list->peso = -1;
	}

}

/*Funcao que remove uma aresta
grafo_l* g = grafo
int a = origem da aresta
int b = destino da aresta
int digrafo = se e' digrafo ou nao
*/ 
int remove_aresta_l(grafo_l* g, int a, int b, int digrafo){

  	node *ptr, *antes;

   	if (g[a].list == NULL){
      return 0;  //lista vazia
  	}

  	else{   //caso a lista nao esteja vazia
    	ptr = g[a].list;
    	antes = g[a].list;
      
    	while (ptr !=NULL){

		 	if (ptr->info == b){

		    	if (ptr == g[a].list){				//caso a remocao seja no comeco
		       		g[a].list = g[a].list->next;	//refaz o encadeamento
		       		free(ptr);						//libera a area do nodo
		       		if(digrafo == 0 && a != b){		//verifica se nao e' digrafo
						remove_aresta_l(g, b, a, 1);
					}
		       		return 1; //removeu
		    	}
		    	else{							//caso a remocao seja no meio ou no fim
		      		antes->next = ptr->next;  	//refaz o encadeamento
		      		free(ptr);                	//libera a area do nodo
		      		if(digrafo == 0 && a != b){	//verifica se nao e' digrafo
						remove_aresta_l(g, b, a, 1);
					}
		      		return 1;   //removeu
		    	}
		 	}
		 	else{
		    	antes = ptr;		//anterior atualizado
		    	ptr = ptr->next;	//continua na lista	
		 	}
    	}

      return 0; //nao achou
  	
  	}

}

/*Funcao que busca se ha um elemento igual ao outro e chama a funcao de
remover o item, pois ele sera adicionado novamente com outro peso
grafo_l* g = grafo
int a = origem da aresta
int b = destino da aresta
int digrafo = se e' digrafo ou nao
*/
void busca_igual(grafo_l* g, int a, int b, int digrafo){

	node* m = (node*)calloc(1, sizeof(node));		//auxiliar
	m = g[a].list;

	if(m->next != NULL)
		m = m->next;

	if(m->info == b){
		remove_aresta_l(g, a, b, digrafo);
		return;
	}

	while(m->next != NULL){
		if(m->info == b){
			remove_aresta_l(g, a, b, digrafo);
			return;
		}
		m = m->next;
	}

	if(m->info == b){
		remove_aresta_l(g,a,b,digrafo);
		return;
	}

	return;

}

/*Funcao que cria uma aresta com base na entrada dada
grafo_l* g = grafo
int a = origem da aresta
int b = destino da aresta
int digrafo = se e' digrafo ou nao
*/
void cria_aresta_la(grafo_l* g, int a, int b, int c, int digrafo){

	node* n = (node*)calloc(1, sizeof(node));		//auxiliar
	n = g[a].list;

	node* m = (node*)calloc(1, sizeof(node));		//atual
	node* o = (node*)calloc(1, sizeof(node));		//anterior

	o = NULL;

	m->info = b;
	m->peso = c;
	m->next = NULL;

	busca_igual(g, a, b, digrafo);

	if(o == NULL){
		/*procura posicao para insercao*/
		while(n != NULL && n->info < b){
			o = n;
			n = n->next;
		}

		/*insere elemeto*/
		//começo
		if(g[a].list->next == NULL){
			g[a].list->next = m;
			m->next = NULL;
		}
		else{
			o->next = m;
			m->next = n;
		}
	}
	else{
		o->peso = c;
	}

	//se nao foir digrafo e' necessario que a funcao seja chamada novamente
	if(digrafo == 0 && a != b){
		cria_aresta_la(g, b, a, c, 1);
	}

	return;

}

/*preenche os grafos inicialmente com a entrada dada utilizando a funcao de insercao
grafo_l* g = grafo
int aresta = numero de arestas
int** arestas = origem e destino das arestas
int digrafo = se e' digrafo ou nao
*/
void preenche_inicial_l(grafo_l* g, int aresta, int origem, int destino, int peso, int digrafo){

	for(int cont = 0; cont < aresta; cont++){
		cria_aresta_la(g, origem, destino, peso, digrafo);
	}

}

/*preenche os grafos de forma trasposta seja digrafo
grafo_l* g = grafo
int aresta = numero de arestas
int** arestas = origem e destino das arestas
int digrafo = se e' digrafo ou nao
*/
void preenche_inicial_la(grafo_l* g, int aresta, int** arestas, int digrafo){

	for(int cont = 0; cont < aresta; cont++){
		cria_aresta_la(g, arestas[cont][1], arestas[cont][0], arestas[cont][2], digrafo);
	}

}

/*acha o menor peso dentre os grafos
grafo_l* g = grafo
int m = numero de vertices
int digrafo = se e' digrafo ou nao
*/
void acha_menor_l(grafo_l* g, int m, int digrafo){

	int menor = 10000;		//coloca um numero grande para facilitar a procura do menor
	int vertice1;
	int vertice2;

	node* n = (node*)calloc(1, sizeof(node));		//auxiliar
	
	for(int cont = 0; cont < m; cont++){
		n = g[cont].list;
		if(n->next != NULL)
			n = n->next;
		while(n != NULL){
			if(n->peso < menor){
				menor = n->peso;
				vertice1 = cont;
				vertice2 = n->info;
			}
			n = n->next;
		}
	}

	if(vertice1 > vertice2 && digrafo == 0){
		int aux = vertice1;
		vertice1 = vertice2;
		vertice2 = aux;
	}

	printf("%d %d\n", vertice1, vertice2);

}

/*imprime os grafos
grafo_l* g = grafo
int m = numero de vertices
*/
void imprime_grafo_l(grafo_l* g, int m){

	node* n = (node*)calloc(1, sizeof(node));		//auxiliar
	node* o = (node*)calloc(1, sizeof(node));		//anterior

	int entrou = 0;
	int faz = 1;

	for(int cont = 0; cont < m; cont++){
		n = g[cont].list->next;
		if(n == NULL){
			printf("%d. ", cont);
			faz = 0;
		}
		if(faz && n->peso != -1){
			printf("%d. ", cont);
		
			if(n->next == NULL && n->peso != -1){
				printf("%d(%d) ", n->info, n->peso);
				printf("\n");
				continue;
			}
			while(n->next != NULL){
				printf("%d(%d) ", n->info, n->peso);
				o = n;
				n = n->next;
				entrou = 1;
			}
			if(entrou == 1){
				printf("%d(%d) ", n->info, n->peso);
			}
		}
		printf("\n");
		faz = 1;
	}

}

/*imprime os adjacentes ao vertice
grafo_l* g = grafo
int vertice = o veritce que deseja imprimir os adjacentes
int* adjacentes = vetor que guarda os adjacentes do vertice
retorno int = numero de adjacentes que o vertice possui
*/
int get_adj(grafo_l* g, int vertice, int adjacentes[2][50]){

	node* n = (node*)calloc(1, sizeof(node));		//auxiliar
	n = g[vertice].list; 

	if(n->next != NULL){
		n = n->next;
	}

	int adj = 0;

	if(n->info != -1 && n->next == NULL){
		adjacentes[0][adj] = n->info;
		adjacentes[1][adj] = n->peso;
		//printf("destino = %d peso = %d\n", n->info, n->peso);
		adj++;
		return adj;
	}

	if(n->next != NULL && n->peso != -1){
		if(n->next == NULL){
			adjacentes[0][adj] = n->info;
			adjacentes[1][adj] = n->peso;
			//printf("destino = %d peso = %d\n", n->info, n->peso);
			adj++;
		}
		else{
			while(n->next != NULL){
				adjacentes[0][adj] = n->info;
				adjacentes[1][adj] = n->peso;
				//printf("destino = %d peso = %d\n", n->info, n->peso);
				adj++;
				n = n->next;
			}
			adjacentes[0][adj] = n->info;
			adjacentes[1][adj] = n->peso;
			//printf("destino = %d peso = %d\n", n->info, n->peso);
			adj++;
		}
	}

	return adj;

}

/*Funcao que destroi as listas de adjacencia do grafo
grafo_l* g = grafo
int vertice = numero de vertices
*/
void destroi_lista(grafo_l* g, int vertice){

	for(int cont = 0; cont < vertice; cont++){

		node* prox;
		node* atual;

		atual = g[cont].list;
		while(atual != NULL){
			prox = atual->next;
			free(atual);
			atual = prox;
		}

	}

}

/*Funcao que inicializa um vetor com um 'item'
int* vet = vetor a ser inicializada
int tam = tamanho do vetor
int item = item que eh o inicializador do vetor
*/
void init_vet(int* vet, int tam, int item){

	for(int cont = 0; cont < tam; cont++)
		vet[cont] = item;

}

/*Funcao para busca em largura
grafo_l* g = grafo para fazer a busca em largura
int vertices = numero de vertices no grafo
int origem = vertice de origem
int destino = vertice de destino
*/
void bfs(grafo_l* g, int vertices, int origem, int destino){

	int color[vertices];			//white = 0, gray = 1, black = 2
	int distancia[vertices];		//distancia entre o vertice de origem e algum vertice do grafo
	int predecessor[vertices];		//predecessor de um vertice com base no vertice de origem

	//inicializacao dos vetores
	init_vet(color, vertices, white);
	init_vet(distancia, vertices, -1);
	init_vet(predecessor, vertices, -1);

	color[origem] = gray;		//origem visitada		
	distancia[origem] = 0;		//distancia da origem a origem = 0
	
	int erro = 0;				//variavel necessaria para o TAD fila

	//fila necessaria para a funcao
	Fila* queue = cria_fila(&erro);

	erro = 0;

	//insere na fila a origem
	insere_fila(queue, origem, &erro);

	erro = 0;

	while(!(fila_vazia(queue, &erro))){

		int topo = queue->itens[queue->inicio];		//pega o topo da fila

		int adjacentes[2][50];							//vetor que guarda os adjacentes do vertices

		int adj = get_adj(g, topo, adjacentes);		//guarda o numero de adjacentes e os adjacentes

		for(int cont = 0; cont < adj; cont++){
			if(color[adjacentes[0][cont]] == white){	//se o vertice nao foi visitado
				color[adjacentes[0][cont]] = gray;
				distancia[adjacentes[0][cont]] = distancia[topo] + 1;
				predecessor[adjacentes[0][cont]] = topo;

				erro = 0;	
				insere_fila(queue, adjacentes[0][cont], &erro);
			}
		}

		int removido;

		remove_fila(queue, &removido, &erro);

		color[topo] = black;		//vertice visitado

	}

	int aux = 0;		//variavel que verifica se foi encontrado um caminho

	//verifica se foi encontrado um caminho
	for(int cont = 0; cont < vertices; cont++){
		if(predecessor[cont] == -1)
			aux++;
	}
	if(aux == vertices){
		printf("\n");
		return;
	}

	int busca[10];				//variavel que guarda o caminho buscado
	init_vet(busca, 10, -1);

	busca[0] = destino;			//guarda o destino(fim do caminho)

	int cont = 1;				//contador que auxilia no armazenamento do caminho

	int pred = destino;			//guarda o acesso para o proximo vertice do caminho

	int achou = 0;				//indica se achou ou nao o caminho

	while(1){
		int auxiliar = predecessor[pred];		//auxiliar que verifica se chegou na origem (caso nao chegaou guarda no vetor busca)
		if(auxiliar == -1){						//se chegou em um vertice sem predecessor
			if(pred != origem){					//verifica se chegou na origem
				printf("\n");
				return;
			}
			achou = 1;
			cont--;
			break;
		}
		busca[cont] = auxiliar;
		cont++;
		int aux = pred;
		pred = predecessor[aux];
	}

	if(achou == 1 && destino != origem){			//se achou printa o vetor busca em ordem contraria
		for(int cont1 = cont; cont1 >= 0; cont1--){
			printf("%d ", busca[cont1]);
		}
		printf("\n");
	}
	if(destino == origem){							//se a origem eh igual o destino
		printf("%d\n", destino);
	}

	//finaliza a fila
	erro = 0;
	esvazia_fila(queue, &erro);	
	destroi_fila(queue, &erro);

}

/*Funcao auxiliar que visita os adjacentes do vetor de origem e os seus subsequentes para busca em profundidade
grafo_l* g = grafo para fazer a busca em profundidade
int* color = vetor que guarda a coloracao dos vertices
int* predecessor = vetor que guarda os predecessores dos vertices com base na origem
int vertex = vertice de origem
int destino = vertice de destino
*/
void dfs_visit(grafo_l* g, int* color, int* predecessor, int vertex, int destino){

	color[vertex] = gray;				//vertice de origem visitado

	int adjacentes[2][50];					//vetor que guarda os adjacentes do vertices

	int adj = get_adj(g, vertex, adjacentes);		//guarda o numero de adjacentes e os adjacentes

	for(int cont = 0; cont < adj; cont++){
		
		if(color[adjacentes[0][cont]] == white){			//se os adjacentes nao foram visitados
			predecessor[adjacentes[0][cont]] = vertex;
			dfs_visit(g, color, predecessor, adjacentes[0][cont], destino);
		}
		color[vertex] = 2;				//vertice visitado e verificado os adjacentes
	}

}

/*Funcao para busca em profundidade
grafo_l* g = grafo para fazer a busca em profundidade
int vertices = numero de vertices do grafo
int origem = origem do grafo
int destino = vertice de destino
*/
void dfs(grafo_l* g, int vertices, int origem, int destino){

	int color[vertices];		//white = 0, gray = 1, black = 2
	int predecessor[vertices];	//vetor que guarda os predecessores dos vertices com base no vertice de origem

	//inicializa os vetores
	init_vet(color, vertices, white);
	init_vet(predecessor, vertices, -1);

	//faz a visita dos vertices adjacentes e subsequentes do vertice de origem para achar um caminho ate o destino
	dfs_visit(g, color, predecessor, origem, destino);

	//verifica se existe caminho entre o vertice de origem e destino
	if(predecessor[destino] == -1 && destino != origem){
		printf("\n");
		return;
	}
	else{

		int busca[20];				//variavel que guarda o caminho buscado
		init_vet(busca, 20, -1);

		busca[0] = destino;			//guarda o destino(fim do caminho)

		int cont = 1;				//contador que auxilia no armazenamento do caminho

		int pred = destino;			//guarda o acesso para o proximo vertice do caminho

		int achou = 0;				//indica se achou ou nao o caminho

		while(1){
			int auxiliar = predecessor[pred];		//auxiliar que verifica se chegou na origem (caso nao chegaou guarda no vetor busca)
			if(auxiliar == -1){						//se chegou em um vertice sem predecessor
				if(pred != origem){					//verifica se chegou na origem
					printf("\n");
					return;
				}
				achou = 1;
				cont--;
				break;
			}
			busca[cont] = auxiliar;
			cont++;
			int aux = pred;
			pred = predecessor[aux];
		}

		if(achou == 1 && destino != origem){			//se achou printa o vetor busca em ordem contraria
			for(int cont1 = cont; cont1 >= 0; cont1--){
				printf("%d ", busca[cont1]);
			}
			printf("\n");
		}
		if(destino == origem){							//se a origem eh igual o destino
			printf("%d\n", destino);
		}
	}

}

/*Funcao que gera a arvore geradora minima de um grafo
grafo_l* g = grafo para fazer a busca em profundidade
int vertices = numero de vertices do grafo
*/
void algPrim(grafo_l* g, int vertices){

	int orig = 0;				//guarda a origem de uma aresta
    int i, j;					//contadores das repeticoes
    int dest, primeiro;			//guarda o destno e verifica se eh o primeiro
    int menorPeso;				//guarda o menor peso das arestas adjacentes
    int predecessor[vertices];	//vetor que guarda os predecessores dos vertices

    //inicializa o vetor de predecessor com '-1'
    init_vet(predecessor, vertices, -1);

    //coloca o predecessor da origem como ele mesmo
    predecessor[orig] = orig;

    //enquanto verdadeiro
    while(1){
    	primeiro = 1;
    	//verifica todos os vertices
    	for(i = 0; i < vertices; i++){
    		if(predecessor[i] != -1){
    			//serve para pegar os adjacentes do vertice i
    			int adjacentes[2][50];
    			init_vet(adjacentes[0], 10, 0);
    			init_vet(adjacentes[1], 10, 0);
    			int adj = get_adj(g, i, adjacentes);
    			//verificacao dos adjacentes
    			for(j = 0; j < adj; j++){
    				if(predecessor[adjacentes[0][j]] == -1){
    					if(primeiro){
    						menorPeso = adjacentes[1][j];
    						orig = i;
    						dest = adjacentes[0][j];
    						primeiro = 0; 
    					}
    					else{
    						if(menorPeso > adjacentes[1][j]){
    							menorPeso = adjacentes[1][j];
    							orig = i;
    							dest = adjacentes[0][j];
    						}
    					}
    				}
    			}
    		}
    	}
    	if(primeiro == 1)
    		break;
    	predecessor[dest] = orig;
    	if(orig > dest)
    		printf("(%d,%d) ", dest, orig);
    	else
    		printf("(%d,%d) ", orig, dest);
    	
    }
    printf("\n");
    
}

void dijkstra1(grafo_l* g, int origem, int destino, int vertices, int arestas){

	int* distancia;			//distancia entre o vertice de origem e algum vertice do grafo
	int* predecessor;		//predecessor de um vertice com base no vertice de origem
	int* verifica;
	int count = 0;
	int count2 = 0;
	int adj = 0;

	int orig = origem;

	distancia = (int*)malloc(sizeof(int) * vertices);
	predecessor = (int*)malloc(sizeof(int) * vertices);
	verifica = (int*)malloc(sizeof(int) * vertices);
	
	//inicializacao dos vetores
	init_vet(distancia, vertices, INT_MAX);
	init_vet(predecessor, vertices, -1);
	init_vet(verifica, vertices, 0);
	
	distancia[origem] = 0;

	priQueue_t* q = creatPriQueue();

	edge** a = (edge**)calloc(sizeof(edge*), 2*arestas);
	for(int cont = 0; cont < 2*arestas; cont++)
		a[cont] = (edge*)calloc(sizeof(edge), 1);

	a[count2]->source = orig;
	a[count2]->destiny = orig;
	a[count2]->weight = 0;
	insertPriQueue(q, a[count2]);
	count2++;

	while(!emptyPriQueue(q)){

		edge removido = removePriQueue(q);

		// printf("removido = %d %d %d\n", removido.source, removido.destiny, removido.weight);

		orig = removido.destiny;

		if(count < 3){
			count++;
			if(adj == 0)
				count++;
		}

		if(!verifica[orig]){
			verifica[orig] = 1;

			int adjacentes[2][50];
			init_vet(adjacentes[0], 50, 0);
			init_vet(adjacentes[1], 50, 0);
			adj = get_adj(g, orig, adjacentes);
			// printf("tem tantos adj %d\n", adj);

			for(int cont = 0; cont < adj; cont++){
				// printf("esta no vertice %d para o vertice %d com peso %d\n", orig, adjacentes[0][cont], adjacentes[1][cont]);
				if(distancia[adjacentes[0][cont]] > distancia[orig] + adjacentes[1][cont]){
					// printf("\n\n\n\n\nta entradno aqui?\n\n\n\n\n\n\n");
					distancia[adjacentes[0][cont]] = distancia[orig] + adjacentes[1][cont];
					predecessor[adjacentes[0][cont]] = orig; 
					// printf("logo que removeu\n");
					// showPriQueue(q);
					a[count2]->source = orig;
					a[count2]->destiny = adjacentes[0][cont];
					a[count2]->weight = distancia[orig] + adjacentes[1][cont];
					insertPriQueue(q, a[count2]);
					count2++;
				}
			}
		}

	}	

	// for(int cont = 0; cont < vertices; cont++)
	// 	printf("%d ", predecessor[cont]);
	// printf("\n");

	if(predecessor[destino] == -1 && destino != origem){
		printf("\n");
		return;
	}
	else{

		int* busca = (int*)malloc(sizeof(int) * 500);				//variavel que guarda o caminho buscado
		init_vet(busca, 500, -1);

		busca[0] = destino;			//guarda o destino(fim do caminho)

		int cont = 1;				//contador que auxilia no armazenamento do caminho

		int pred = destino;			//guarda o acesso para o proximo vertice do caminho

		int achou = 0;				//indica se achou ou nao o caminho

		while(1){
			int auxiliar = predecessor[pred];		//auxiliar que verifica se chegou na origem (caso nao chegaou guarda no vetor busca)
			if(auxiliar == origem){
				busca[cont] = auxiliar;
				achou = 1;
				break;
			}
			busca[cont] = auxiliar;
			cont++;
			int aux = pred;
			pred = predecessor[aux];
		}

		if(achou == 1 && destino != origem){			//se achou printa o vetor busca em ordem contraria
			for(int cont1 = cont; cont1 >= 0; cont1--){
				printf("%d ", busca[cont1]);
			}
			printf("\n");
		}
		if(destino == origem){							//se a origem eh igual o destino
			printf("%d\n", destino);
		}
		free(busca);
	}

	for(int cont = 0; cont < 2*arestas; cont++)
		free(a[cont]);
	free(a);
	free(verifica);
	free(distancia);
	free(predecessor);

    liberatePriQueue(q);

}