/*
***************************************************

	USP - ICMC
	Modelagem Computacional em Grafos - SCC0216 - 2018
	
	TAD fila prioritaria

	Lucas Noriyuki Yoshida - 10262586

****************************************************
*/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "priQueue.h"

typedef struct node{

	edge *data;
	struct node *next, *prev;

}node_t;

struct priQueue{
	
	node_t *first, *last;

};

priQueue_t* creatPriQueue(){

	priQueue_t *q = (priQueue_t*)calloc(sizeof(priQueue_t), 1);
	return q;

}

unsigned char emptyPriQueue(priQueue_t *f){

	if(f->first == NULL)
		return 1;
	else{
		//printf("verificacao do vazio = %d %d %d\n", f->first->data->source,f->first->data->destiny, f->first->data->weight);
		return 0;
	}
	
}

void showPriQueue(priQueue_t *f){

	node_t *q = f->first;

	while(q != NULL){
		printf("(%d, %d, %d) ", q->data->source, q->data->destiny, q->data->weight);
		q = q->next;
	}
	printf("\n");

}

void insertPriQueue(priQueue_t *f, edge *a){
	
	node_t *n = (node_t*)calloc(sizeof(node_t), 1);
	n->data = a;
	
	if(emptyPriQueue(f)){
		// printf("inseriu primeiro\n");
		f->first = n;
		f->last = n;
	}
	else{
		
		node_t *aux = f->first;
	
		while(aux != NULL && (aux->data->weight < n->data->weight || (aux->data->weight == n->data->weight && aux->data->destiny < n->data->destiny))){
			// printf("whileee\n");
			aux = aux->next;
		}
		
		if(aux == NULL){
			// printf("inseriu fim\n");
			f->last->next = n;
			n->prev = f->last;
			f->last = n;
		}
		else{
			n->next = aux;
			if(aux->prev == NULL){
				// printf("inseriu comeco\n");
				aux->prev = n;
				f->first = n;
			}
			else{
				// printf("inseriu meio\n");
				aux->prev->next = n;
				n->prev = aux->prev;
				aux->prev = n;
			}
		}
	}

}

void updatePriQueue(priQueue_t *f, int source, int destiny){

	node_t* aux = NULL;

	if(!emptyPriQueue(f)){
		aux = f->first;
		while(aux != NULL){
			if(aux->data->source == source){
				if(aux->data->destiny == destiny){
					if(aux != f->first){
						if(aux->next != NULL)
							aux->next->prev = aux->prev;
						if(aux->prev != NULL)	
							aux->prev->next = aux->next;
						aux->prev = NULL;
						aux->next = f->first;
						f->first->prev = aux;
						f->first = aux;
						removePriQueue(f);
						return;
					}
					else{
						removePriQueue(f);
						return;
					}
				}
			}
			aux = aux->next;
		}

	}

}

edge removePriQueue(priQueue_t *f){

	node_t *aux = NULL;
	
	if(!emptyPriQueue(f)){
		aux = f->first;
		f->first = aux->next;
		
		if(aux->next == NULL)
			f->last = NULL;
		else
			aux->next->prev = NULL;
		
		edge a = *(aux->data);
		
		free(aux);
		
		return a;
	}

}

void liberatePriQueue(priQueue_t *f){
	
	node_t *n = f->first;

	while(n != NULL){
		f->first = n->next;
		
		free(n);
		
		n = f->first;
	}

	free(f);

}