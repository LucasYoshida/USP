/*
***************************************************

	USP - ICMC
	Modelagem Computacional em Grafos - SCC0216 - 2018
	
	Grafos em Lista de Adjacência

	Lucas Noriyuki Yoshida - 10262586

****************************************************
*/

#include <stdio.h>
#include <stdlib.h>
#include "lista.h"
#include "fila.h"

/*Funcao que cria um grafo por lista de adjacencia
grafo_l* g = grafo
int n = numero de vertices
*/
void cria_grafo_l(grafo_l* g, int n){

	for(int cont = 0; cont < n; cont++){
		g[cont].list = (node*)calloc(1, sizeof(node));
		g[cont].list->next = NULL;
		g[cont].list->info = -1;
		g[cont].list->peso = -1;
	}

}

/*Funcao que remove uma aresta
grafo_l* g = grafo
int a = origem da aresta
int b = destino da aresta
int digrafo = se e' digrafo ou nao
*/ 
int remove_aresta_l(grafo_l* g, int a, int b, int digrafo){

  	node *ptr, *antes;

   	if (g[a].list == NULL){
      return 0;  //lista vazia
  	}

  	else{   //caso a lista nao esteja vazia
    	ptr = g[a].list;
    	antes = g[a].list;
      
    	while (ptr !=NULL){

		 	if (ptr->info == b){

		    	if (ptr == g[a].list){				//caso a remocao seja no comeco
		       		g[a].list = g[a].list->next;	//refaz o encadeamento
		       		free(ptr);						//libera a area do nodo
		       		if(digrafo == 0 && a != b){		//verifica se nao e' digrafo
						remove_aresta_l(g, b, a, 1);
					}
		       		return 1; //removeu
		    	}
		    	else{							//caso a remocao seja no meio ou no fim
		      		antes->next = ptr->next;  	//refaz o encadeamento
		      		free(ptr);                	//libera a area do nodo
		      		if(digrafo == 0 && a != b){	//verifica se nao e' digrafo
						remove_aresta_l(g, b, a, 1);
					}
		      		return 1;   //removeu
		    	}
		 	}
		 	else{
		    	antes = ptr;		//anterior atualizado
		    	ptr = ptr->next;	//continua na lista	
		 	}
    	}

      return 0; //nao achou
  	
  	}

}

/*Funcao que busca se ha um elemento igual ao outro e chama a funcao de
remover o item, pois ele sera adicionado novamente com outro peso
grafo_l* g = grafo
int a = origem da aresta
int b = destino da aresta
int digrafo = se e' digrafo ou nao
*/
void busca_igual(grafo_l* g, int a, int b, int digrafo){

	node* m = (node*)calloc(1, sizeof(node));		//auxiliar
	m = g[a].list;

	if(m->next != NULL)
		m = m->next;

	if(m->info == b){
		remove_aresta_l(g, a, b, digrafo);
		return;
	}

	while(m->next != NULL){
		if(m->info == b){
			remove_aresta_l(g, a, b, digrafo);
			return;
		}
		m = m->next;
	}

	if(m->info == b){
		remove_aresta_l(g,a,b,digrafo);
		return;
	}

	return;

}

/*Funcao que cria uma aresta com base na entrada dada
grafo_l* g = grafo
int a = origem da aresta
int b = destino da aresta
int digrafo = se e' digrafo ou nao
*/
void cria_aresta_la(grafo_l* g, int a, int b, int c, int digrafo){

	node* n = (node*)calloc(1, sizeof(node));		//auxiliar
	n = g[a].list;

	node* m = (node*)calloc(1, sizeof(node));		//atual
	node* o = (node*)calloc(1, sizeof(node));		//anterior

	o = NULL;

	m->info = b;
	m->peso = c;
	m->next = NULL;

	busca_igual(g, a, b, digrafo);

	if(o == NULL){
		/*procura posicao para insercao*/
		while(n != NULL && n->info < b){
			o = n;
			n = n->next;
		}

		/*insere elemeto*/
		//começo
		if(g[a].list->next == NULL){
			g[a].list->next = m;
			m->next = NULL;
		}
		else{
			o->next = m;
			m->next = n;
		}
	}
	else{
		o->peso = c;
	}

	//se nao foir digrafo e' necessario que a funcao seja chamada novamente
	if(digrafo == 0 && a != b){
		cria_aresta_la(g, b, a, c, 1);
	}

	return;

}

/*preenche os grafos inicialmente com a entrada dada utilizando a funcao de insercao
grafo_l* g = grafo
int aresta = numero de arestas
int** arestas = origem e destino das arestas
int digrafo = se e' digrafo ou nao
*/
void preenche_inicial_l(grafo_l* g, int aresta, int** arestas, int digrafo){

	for(int cont = 0; cont < aresta; cont++){
		cria_aresta_la(g, arestas[cont][0], arestas[cont][1], arestas[cont][2], digrafo);
	}

}

/*preenche os grafos de forma trasposta seja digrafo
grafo_l* g = grafo
int aresta = numero de arestas
int** arestas = origem e destino das arestas
int digrafo = se e' digrafo ou nao
*/
void preenche_inicial_la(grafo_l* g, int aresta, int** arestas, int digrafo){

	for(int cont = 0; cont < aresta; cont++){
		cria_aresta_la(g, arestas[cont][1], arestas[cont][0], arestas[cont][2], digrafo);
	}

}

/*acha o menor peso dentre os grafos
grafo_l* g = grafo
int m = numero de vertices
int digrafo = se e' digrafo ou nao
*/
void acha_menor_l(grafo_l* g, int m, int digrafo){

	int menor = 10000;		//coloca um numero grande para facilitar a procura do menor
	int vertice1;
	int vertice2;

	node* n = (node*)calloc(1, sizeof(node));		//auxiliar
	
	for(int cont = 0; cont < m; cont++){
		n = g[cont].list;
		if(n->next != NULL)
			n = n->next;
		while(n != NULL){
			if(n->peso < menor){
				menor = n->peso;
				vertice1 = cont;
				vertice2 = n->info;
			}
			n = n->next;
		}
	}

	if(vertice1 > vertice2 && digrafo == 0){
		int aux = vertice1;
		vertice1 = vertice2;
		vertice2 = aux;
	}

	printf("%d %d\n", vertice1, vertice2);

}

/*imprime os grafos
grafo_l* g = grafo
int m = numero de vertices
*/
void imprime_grafo_l(grafo_l* g, int m){

	node* n = (node*)calloc(1, sizeof(node));		//auxiliar
	node* o = (node*)calloc(1, sizeof(node));		//anterior

	int entrou = 0;

	for(int cont = 0; cont < m; cont++){
		n = g[cont].list->next;
		if(n->peso != -1){
			printf("%d. ", cont);
		
			if(n->next == NULL && n->peso != -1){
				printf("%d(%d) ", n->info, n->peso);
				printf("\n");
				continue;
			}
			while(n->next != NULL){
				printf("%d(%d) ", n->info, n->peso);
				o = n;
				n = n->next;
				entrou = 1;
			}
			if(entrou == 1){
				printf("%d(%d) ", n->info, n->peso);
			}
		}
		printf("\n");
	}

}

/*imprime os adjacentes ao vertice
grafo_l* g = grafo
int vertice = o veritce que deseja imprimir os adjacentes
int* adjacentes = vetor que guarda os adjacentes do vertice
retorno int = numero de adjacentes que o vertice possui
*/
int get_adj(grafo_l* g, int vertice, int* adjacentes){

	node* n = (node*)calloc(1, sizeof(node));		//auxiliar
	n = g[vertice].list; 

	if(n->next != NULL){
		n = n->next;
	}

	int adj = 0;

	if(n->next != NULL && n->peso != -1){
		if(n->next == NULL){
			adjacentes[adj] = n->info;
			adj++;
		}
		else{
			while(n->next != NULL){
				adjacentes[adj] = n->info;
				adj++;
				n = n->next;
			}
			adjacentes[adj] = n->info;
			adj++;
		}
	}

	return adj;

}

/*Funcao que destroi as listas de adjacencia do grafo
grafo_l* g = grafo
int vertice = numero de vertices
*/
void destroi_lista(grafo_l* g, int vertice){

	for(int cont = 0; cont < vertice; cont++){

		node* prox;
		node* atual;

		atual = g[cont].list;
		while(atual != NULL){
			prox = atual->next;
			free(atual);
			atual = prox;
		}

	}

}

/*Funcao que inicializa um vetor com um 'item'
int* vet = vetor a ser inicializada
int tam = tamanho do vetor
int item = item que eh o inicializador do vetor
*/
void init_vet(int* vet, int tam, int item){

	for(int cont = 0; cont < tam; cont++)
		vet[cont] = item;

}

/*Funcao para busca em largura
grafo_l* g = grafo para fazer a busca em largura
int vertices = numero de vertices no grafo
int origem = vertice de origem
int destino = vertice de destino
*/
void bfs(grafo_l* g, int vertices, int origem, int destino){

	int color[vertices];			//white = 0, gray = 1, black = 2
	int distancia[vertices];		//distancia entre o vertice de origem e algum vertice do grafo
	int predecessor[vertices];		//predecessor de um vertice com base no vertice de origem

	//inicializacao dos vetores
	init_vet(color, vertices, white);
	init_vet(distancia, vertices, -1);
	init_vet(predecessor, vertices, -1);

	color[origem] = gray;		//origem visitada		
	distancia[origem] = 0;		//distancia da origem a origem = 0
	
	int erro = 0;				//variavel necessaria para o TAD fila

	//fila necessaria para a funcao
	Fila* queue = cria_fila(&erro);

	erro = 0;

	//insere na fila a origem
	insere_fila(queue, origem, &erro);

	erro = 0;

	while(!(fila_vazia(queue, &erro))){

		int topo = queue->itens[queue->inicio];		//pega o topo da fila

		int adjacentes[10];							//vetor que guarda os adjacentes do vertices

		int adj = get_adj(g, topo, adjacentes);		//guarda o numero de adjacentes e os adjacentes

		for(int cont = 0; cont < adj; cont++){
			if(color[adjacentes[cont]] == white){	//se o vertice nao foi visitado
				color[adjacentes[cont]] = gray;
				distancia[adjacentes[cont]] = distancia[topo] + 1;
				predecessor[adjacentes[cont]] = topo;

				erro = 0;	
				insere_fila(queue, adjacentes[cont], &erro);
			}
		}

		int removido;

		remove_fila(queue, &removido, &erro);

		color[topo] = black;		//vertice visitado

	}

	int aux = 0;		//variavel que verifica se foi encontrado um caminho

	//verifica se foi encontrado um caminho
	for(int cont = 0; cont < vertices; cont++){
		if(predecessor[cont] == -1)
			aux++;
	}
	if(aux == vertices){
		printf("\n");
		return;
	}

	int busca[10];				//variavel que guarda o caminho buscado
	init_vet(busca, 10, -1);

	busca[0] = destino;			//guarda o destino(fim do caminho)

	int cont = 1;				//contador que auxilia no armazenamento do caminho

	int pred = destino;			//guarda o acesso para o proximo vertice do caminho

	int achou = 0;				//indica se achou ou nao o caminho

	while(1){
		int auxiliar = predecessor[pred];		//auxiliar que verifica se chegou na origem (caso nao chegaou guarda no vetor busca)
		if(auxiliar == -1){						//se chegou em um vertice sem predecessor
			if(pred != origem){					//verifica se chegou na origem
				printf("\n");
				return;
			}
			achou = 1;
			cont--;
			break;
		}
		busca[cont] = auxiliar;
		cont++;
		int aux = pred;
		pred = predecessor[aux];
	}

	if(achou == 1 && destino != origem){			//se achou printa o vetor busca em ordem contraria
		for(int cont1 = cont; cont1 >= 0; cont1--){
			printf("%d ", busca[cont1]);
		}
		printf("\n");
	}
	if(destino == origem){							//se a origem eh igual o destino
		printf("%d\n", destino);
	}

	//finaliza a fila
	erro = 0;
	esvazia_fila(queue, &erro);	
	destroi_fila(queue, &erro);

}

/*Funcao auxiliar que visita os adjacentes do vetor de origem e os seus subsequentes para busca em profundidade
grafo_l* g = grafo para fazer a busca em profundidade
int* color = vetor que guarda a coloracao dos vertices
int* predecessor = vetor que guarda os predecessores dos vertices com base na origem
int vertex = vertice de origem
int destino = vertice de destino
*/
void dfs_visit(grafo_l* g, int* color, int* predecessor, int vertex, int destino){

	color[vertex] = gray;				//vertice de origem visitado

	int adjacentes[10];					//vetor que guarda os adjacentes do vertices

	int adj = get_adj(g, vertex, adjacentes);		//guarda o numero de adjacentes e os adjacentes

	for(int cont = 0; cont < adj; cont++){
		
		if(color[adjacentes[cont]] == white){			//se os adjacentes nao foram visitados
			predecessor[adjacentes[cont]] = vertex;
			dfs_visit(g, color, predecessor, adjacentes[cont], destino);
		}
		color[vertex] = 2;				//vertice visitado e verificado os adjacentes
	}

}

/*Funcao para busca em profundidade
grafo_l* g = grafo para fazer a busca em profundidade
int* color = vetor que guarda a coloracao dos vertices
int* predecessor = vetor que guarda os predecessores dos vertices com base na origem
int vertex = vertice de origem
int destino = vertice de destino
*/
void dfs(grafo_l* g, int vertices, int origem, int destino){

	int color[vertices];		//white = 0, gray = 1, black = 2
	int predecessor[vertices];	//vetor que guarda os predecessores dos vertices com base no vertice de origem

	//inicializa os vetores
	init_vet(color, vertices, white);
	init_vet(predecessor, vertices, -1);

	//faz a visita dos vertices adjacentes e subsequentes do vertice de origem para achar um caminho ate o destino
	dfs_visit(g, color, predecessor, origem, destino);

	//verifica se existe caminho entre o vertice de origem e destino
	if(predecessor[destino] == -1 && destino != origem){
		printf("\n");
		return;
	}
	else{

		int busca[10];				//variavel que guarda o caminho buscado
		init_vet(busca, 10, -1);

		busca[0] = destino;			//guarda o destino(fim do caminho)

		int cont = 1;				//contador que auxilia no armazenamento do caminho

		int pred = destino;			//guarda o acesso para o proximo vertice do caminho

		int achou = 0;				//indica se achou ou nao o caminho

		while(1){
			int auxiliar = predecessor[pred];		//auxiliar que verifica se chegou na origem (caso nao chegaou guarda no vetor busca)
			if(auxiliar == -1){						//se chegou em um vertice sem predecessor
				if(pred != origem){					//verifica se chegou na origem
					printf("\n");
					return;
				}
				achou = 1;
				cont--;
				break;
			}
			busca[cont] = auxiliar;
			cont++;
			int aux = pred;
			pred = predecessor[aux];
		}

		if(achou == 1 && destino != origem){			//se achou printa o vetor busca em ordem contraria
			for(int cont1 = cont; cont1 >= 0; cont1--){
				printf("%d ", busca[cont1]);
			}
			printf("\n");
		}
		if(destino == origem){							//se a origem eh igual o destino
			printf("%d\n", destino);
		}
	}

}