/*
***************************************************

	USP - ICMC
	Modelagem Computacional em Grafos - SCC0216 - 2018
	
	TAD Fila para busca

	Lucas Noriyuki Yoshida - 10262586

****************************************************
*/

#include <stdio.h>
#include <stdlib.h>
#include "fila.h"

Fila* cria_fila(int *flagErro){
	
	Fila *F = (Fila*)malloc(sizeof(Fila));
	if(F == NULL) {
		*flagErro = 1; // ERRO_MEMORIA_INSUFICIENTE
		return F;
	}
	else
		*flagErro = 0; // SUCESSO
	

	for(int cont = 0; cont < TamFila; cont++)
		F->itens[cont] = 0;
	F->inicio=0;
	F->fim=0;
	F->total=0;
	return F;

}

void esvazia_fila(Fila *F , int *flagErro) {
	
	if(F != NULL){
		F->inicio=0;
		F->fim=0;
		F->total=0;
		*flagErro = 0; //SUCESSO
	}
	else
		*flagErro = 1; // ERRO_PONTEIRO_NULO

}

void destroi_fila(Fila *F, int *flagErro) {

	if(F != NULL){
		free(F);
	*flagErro = 0; //SUCESSO
	}

	else
		*flagErro = 1; // ERRO_PONTEIRO_NULO

}

int fila_vazia(Fila *F,int *flagErro) {
	
	if(F != NULL){
		*flagErro = 0; //SUCESSO
		if (F->total==0)
			return 1;
		else 
			return 0;
	}
	else {
		*flagErro = 1; //ERRO_PONTEIRO_NULO
		return 1;
	}

}

int fila_cheia(Fila *F,int *flagErro) {
	
	if(F != NULL){
		*flagErro = 0; //SUCESSO
		if (F->total==TamFila-1) 
			return 1;
		else 
			return 0;
	}
	else {
		*flagErro = 1; // ERRO_PONTEIRO_NULO
		return 0;
	}

}

int tamanho_fila(Fila *F,int *flagErro) {
	
	if(F != NULL){
		*flagErro = 0; //SUCESSO
		return F->total;
	}
	else{
		*flagErro = 1; // ERRO_PONTEIRO_NULO
		return -1;
	}

}

void insere_fila(Fila *F, int X, int *erro) {

	if(!fila_cheia(F,erro)) {
		if(*erro == 0) {
			*erro=0;
			F->total++;
			F->itens[F->fim]=X;
			if(F->fim==TamFila-1) 
				F->fim=0;
			else 
				F->fim++;
		}
	}
	else 
		*erro=1;

	return;

}

void remove_fila(Fila *F, int *X, int *erro) {
	
	if(!fila_vazia(F,erro)){
		if(*erro == 0){
			*erro=0;
			F->total--;
			*X=F->itens[F->inicio];
		if(F->inicio==TamFila-1) 
			F->inicio=0;
		else 
			F->inicio++;
		}
	}

	else 
		*erro=1;

}