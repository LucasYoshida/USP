/*
***************************************************

	USP - ICMC
	Modelagem Computacional em Grafos - SCC0216 - 2018
	
	Grafos em Lista de Adjacência

	Lucas Noriyuki Yoshida - 10262586

****************************************************
*/

#include <stdio.h>
#include <stdlib.h>

#define white 0
#define gray 1
#define black 2

typedef struct node {
	
	int info;			//guarda o vertice de destino da aresta que interliga o grafo
	int peso;			//o peso dessa aresta
	struct node *next;

} node;

typedef struct Grafo_l{
	
	node *list;
	int n;				//o numero de vertices

} grafo_l;

void cria_grafo_l(grafo_l* g, int n);

int remove_aresta_l(grafo_l* g, int a, int b, int digrafo);

void busca_igual(grafo_l* g, int a, int b, int digrafo);

void cria_aresta_la(grafo_l* g, int a, int b, int c, int digrafo);

void preenche_inicial_l(grafo_l* g, int aresta, int** arestas, int digrafo);

void preenche_inicial_la(grafo_l* g, int aresta, int** arestas, int digrafo);

void acha_menor_l(grafo_l* g, int m, int digrafo);

void imprime_grafo_l(grafo_l* g, int m);

int get_adj(grafo_l* g, int vertice, int* adjacentes);

void destroi_lista(grafo_l* g, int vertice);

void init_vet(int* vet, int tam, int item);

void bfs(grafo_l* g, int vertices, int origem, int destino);

void dfs_visit(grafo_l* g, int* color, int* predecessor, int vertex, int destino);

void dfs(grafo_l* g, int vertices, int origem, int destino);

void dfs_visit_total(grafo_l* g, int* color, int* predecessor, int vertex, int* time, int* time_ida, int* time_volta, int* topologica, int* contador);

void dfs_total(grafo_l* g, int vertices);