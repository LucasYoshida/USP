/*
***************************************************

	USP - ICMC
	Modelagem Computacional em Grafos - SCC0216 - 2018
	
	Grafos em Matriz de Adjacência

	Lucas Noriyuki Yoshida - 10262586

****************************************************
*/

#include <stdio.h>
#include <stdlib.h>

typedef struct Grafo_matriz{

	int n;		//número de no's
	int **mat; 	//matriz	

} grafo_m;

void cria_grafo(grafo_m* g, int n);

void cria_aresta(grafo_m* g, int a, int b, int c, int digrafo);

void preenche_inicial(grafo_m* g, int aresta, int** arestas, int digrafo);

void acha_menor(grafo_m* g, int n);

void remove_aresta(grafo_m* g, int a, int b, int digrafo);

void imprime_grafo(grafo_m* g);

void imprime_vertice(grafo_m* g, int vertice);

void imprime_transposto(grafo_m* g);

void destroi_matriz(grafo_m* g);