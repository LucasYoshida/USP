/*
***************************************************

	USP - ICMC
	Modelagem Computacional em Grafos - SCC0216 - 2018
	
	Grafos em Matriz de Adjacência

	Lucas Noriyuki Yoshida - 10262586

****************************************************
*/

#include <stdio.h>
#include <stdlib.h>
#include "matriz.h"

/*Funcao que cria a martriz com base no numero de vertices
grafp_m* g = grafo
int n = nuemro de vertices
*/
void cria_grafo(grafo_m* g, int n){

	//alocacao da matriz na heap
	g->mat = (int**)calloc(n, sizeof(int*));
	for(int cont = 0; cont < n; cont++){
		g->mat[cont] = (int*)calloc(n, sizeof(int));
	}

	//para diferenciar os pesos a matriz vai ser preenchida com o valor '-1'
	for(int cont = 0; cont < n; cont++){
		for(int cont1 = 0; cont1 < n; cont1++){
			g->mat[cont][cont1] = -1;
		}
	}

	g->n = n;

}

/*Funcao que cria uma aresta, que seria colocar na matriz o peso da aresta
com base na origem e no destino da aresta
grafo_m* g = grafo
int a = origem
int b = destino
int c = peso
int digrafo = se e' digrafo ou nao
*/
void cria_aresta(grafo_m* g, int a, int b, int c, int digrafo){

	g->mat[a][b] = c;
	if(digrafo == 0)		//verifica se nao eh digrafo
		g->mat[b][a] = c;

}

/*Funcao que pega a matriz que guarda a entrada e preenche o grafo inicialmente
antes das operacoes requeridas pelo usuario
grafo_m* g = grafo
int aresta = numero de arestas
int** arestas = matriz que guarda a origem, destino e peso das arestas
int digrafo = se e' digrafo ou nao
*/
void preenche_inicial(grafo_m* g, int aresta, int** arestas, int digrafo){

	for(int cont = 0; cont < aresta; cont++){
		cria_aresta(g, arestas[cont][0], arestas[cont][1], arestas[cont][2], digrafo);
	}

}

/*Funcao que percorre a matriz e encontra o menor peso em uma das arestas
grafo_m" g = grafo
int n = numero de vertices
*/
void acha_menor(grafo_m* g, int n){

	int menor = 10000;		//coloca um numero grande para facilitar a procura do menor
	int vertice1;
	int vertice2;
	for(int cont = 0; cont < n; cont++){
		for(int cont1 = 0; cont1 < n; cont1++){
			if(g->mat[cont][cont1] < menor && g->mat[cont][cont1] != -1){
				menor = g->mat[cont][cont1];
				vertice1 = cont;
				vertice2 = cont1;
			}
		}
	}

	if(vertice1 > vertice2){
		int aux = vertice1;
		vertice1 = vertice2;
		vertice2 = aux;
	}

	printf("%d %d\n", vertice1, vertice2);

}

/*Funcao que remove uma aresta, simplesmente colocando '-1' no seu lugar
com base na sua origem e destino
grafo_m* g = grafo
int a = origem
int b = destino
int digrafo = se e' digrafo ou nao
*/
void remove_aresta(grafo_m* g, int a, int b, int digrafo){

	g->mat[a][b] = -1;
	if(digrafo == 0)
		g->mat[b][a] = -1;

}

/*Funcao que imprime o grafo inteiro
grafo*m g = grafo
*/
void imprime_grafo(grafo_m* g){

	for(int cont = 0; cont < g->n; cont++){
		for(int cont1 = 0; cont1 < g->n; cont1++){
			if(g->mat[cont][cont1] != -1)
				printf("%d ", g->mat[cont][cont1]);
			else
				printf(". ");
		}
		printf("\n");
	}

}

/*Funcao que imprime os vertices adjacentes ao pedido
grafo_m*g = grafo
int vertice = numero de vertices
*/
void imprime_vertice(grafo_m* g, int vertice){

	for(int cont = 0; cont < g->n; cont++){
		if(g->mat[vertice][cont] != -1)
			printf("%d ", cont);
	}
	printf("\n");

}

/*Funcao que imprime a matriz transposta do grafo
grafo_m* g = grafo
*/
void imprime_transposto(grafo_m* g){

	for(int cont = 0; cont < g->n; cont++){
		for(int cont1 = 0; cont1 < g->n; cont1++){
			if(g->mat[cont1][cont] != -1)
				printf("%d ", g->mat[cont1][cont]);
			else
				printf(". ");
		}
		printf("\n");
	}

}

/*Funcao que destroi uma matriz, desaloca ela
grafo_m* g = grafo
*/
void destroi_matriz(grafo_m* g){

	for(int cont = 0; cont < g->n; cont++){
		free(g->mat[cont]);
	}
	free(g->mat);

}
