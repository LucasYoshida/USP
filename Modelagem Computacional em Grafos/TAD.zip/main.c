/*
***************************************************

	USP - ICMC
	Modelagem Computacional em Grafos - SCC0216 - 2018
	
	Grafos em Lista e Matriz de Adjacência

	Lucas Noriyuki Yoshida - 10262586

****************************************************
*/

#include <stdio.h>
#include <stdlib.h>
#include "matriz.h"
#include "lista.h"

//********************************************************

int main (){

	grafo_m g;				//grafo referente a matriz de adjacencia
	grafo_l* g1;			//grafo referente a lista de adjacencia

	int aresta, vertice;	//guarda o numero de arestas e vertices

	int** arestas;			//guarda quais são as arestas (origem/destino e peso)

	char* op;				//identifica a operação requerida pelo usuario		
	char* entrada;			//guarda a entrada (D = digrafo, G = grafo, M = matriz de adjacencia, L = lista de adjacencia)

	char e1, e2;			//e1 ('D' = digrafo, 'G', grafo) e2 ('M' = matriz, 'L' = lista)

	int digrafo = 0;		//indica se e' um digrafo ou nao (1 = sim, 0 = nao)

//********************************************************

	//alocação na heap
	op = (char*)calloc(2, sizeof(char));
	entrada = (char*)calloc(8, sizeof(char));

	scanf("%c %c %d %d", &e1, &e2, &vertice, &aresta);

	g1 = (grafo_l*)calloc(vertice, sizeof(grafo_l));

	if(e1 == 'D')		//verifica se e' digrafo
		digrafo = 1;

	//alocacao das informacoes das aresta (origem/destino/peso)
	arestas = (int**)calloc(1000, sizeof(int*));
	for(int cont = 0; cont < 1000; cont++){
		arestas[cont] = (int*)calloc(3, sizeof(int));
	}

	//entrada das informacoes das arestas
	for(int cont = 0; cont < aresta; cont++){
		scanf("%d %d %d", &arestas[cont][0], &arestas[cont][1], &arestas[cont][2]);
	}
	
//********************************************************

	//caso utilize a matriz de adjacencia
	if(e2 == 'M'){
		//cria a matriz de adjacencia
		cria_grafo(&g, vertice);
		preenche_inicial(&g, aresta, arestas, digrafo);

		int aresta1, aresta2;
		int peso;

		//parte das operacoes requeridas pelo usuario
		while(scanf("%s %d %d %d", op, &aresta1, &aresta2, &peso) != EOF){

			if(op[0] == 'A'){
				cria_aresta(&g, aresta1, aresta2, peso, digrafo);
			}
			if(op[0] == 'R'){
				remove_aresta(&g, aresta1, aresta2, digrafo);
			}
			if(op[0] == 'M'){
				acha_menor(&g, vertice);
			}
			if(op[0] == 'I' && op[1] == 'G'){
				imprime_grafo(&g);
			}
			if(op[0] == 'V'){
				imprime_vertice(&g, aresta1);
			}
			if(op[0] == 'I' && op[1] == 'T' && e1 == 'D'){
				imprime_transposto(&g);
			}
		}

		destroi_matriz(&g);

	}

//********************************************************

	//caso utilize a lista de adjacencia
	if(e2 == 'L'){
		//cria a lista de adjacencia
		cria_grafo_l(g1, vertice);

		preenche_inicial_l(g1, aresta, arestas, digrafo);

		int aresta1, aresta2;
		int peso;
		
		//esse segundo grafo serve para caso seja necessario iumprimir o trasposto
		grafo_l* g2;
		g2 = (grafo_l*)calloc(vertice, sizeof(grafo_l));
		
		cria_grafo_l(g2, vertice);

		preenche_inicial_la(g2, aresta, arestas, digrafo);

		//parte das operacoes requeridas pelo usuario
		while(scanf("%s %d %d %d", op, &aresta1, &aresta2, &peso) != EOF){

			if(op[0] == 'A'){
				cria_aresta_la(g1, aresta1, aresta2, peso, digrafo);
				if(digrafo == 1)
					cria_aresta_la(g2, aresta2, aresta1, peso, digrafo);
			}
			if(op[0] == 'R'){
				remove_aresta_l(g1, aresta1, aresta2, digrafo);
				if(digrafo == 1)
					remove_aresta_l(g2, aresta2, aresta1, digrafo);
			}
			if(op[0] == 'M'){
				acha_menor_l(g1, vertice, digrafo);
			}
			if(op[0] == 'I' && op[1] == 'G'){
				imprime_grafo_l(g1, vertice);
			}
			if(op[0] == 'V'){
				imprime_vertice_l(g1, aresta1);
			}
			if(op[0] == 'I' && op[1] == 'T' && digrafo == 1){
				imprime_grafo_l(g2, vertice);
			}
		}

		destroi_lista(g1, vertice);
		destroi_lista(g2, vertice);
		free(g2);

	}

//********************************************************

	//free
	free(op);
	free(entrada);
	for(int cont = 0; cont < 3; cont++)
		free(arestas[cont]);
	free(arestas);
	free(g1);

	return 0;

}