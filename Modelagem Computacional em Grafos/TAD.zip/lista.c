/*
***************************************************

	USP - ICMC
	Modelagem Computacional em Grafos - SCC0216 - 2018
	
	Grafos em Lista de Adjacência

	Lucas Noriyuki Yoshida - 10262586

****************************************************
*/

#include <stdio.h>
#include <stdlib.h>
#include "lista.h"

/*Funcao que cria um grafo por lista de adjacencia
grafo_l* g = grafo
int n = numero de vertices
*/
void cria_grafo_l(grafo_l* g, int n){

	for(int cont = 0; cont < n; cont++){
		g[cont].list = (node*)calloc(1, sizeof(node));
		g[cont].list->next = NULL;
		g[cont].list->info = -1;
		g[cont].list->peso = -1;
	}

}

/*Funcao que remove uma aresta
grafo_l* g = grafo
int a = origem da aresta
int b = destino da aresta
int digrafo = se e' digrafo ou nao
*/ 
int remove_aresta_l(grafo_l* g, int a, int b, int digrafo){

  	node *ptr, *antes;

   	if (g[a].list == NULL){
      return 0;  //lista vazia
  	}

  	else{   //caso a lista nao esteja vazia
    	ptr = g[a].list;
    	antes = g[a].list;
      
    	while (ptr !=NULL){

		 	if (ptr->info == b){

		    	if (ptr == g[a].list){				//caso a remocao seja no comeco
		       		g[a].list = g[a].list->next;	//refaz o encadeamento
		       		free(ptr);						//libera a area do nodo
		       		if(digrafo == 0 && a != b){		//verifica se nao e' digrafo
						remove_aresta_l(g, b, a, 1);
					}
		       		return 1; //removeu
		    	}
		    	else{							//caso a remocao seja no meio ou no fim
		      		antes->next = ptr->next;  	//refaz o encadeamento
		      		free(ptr);                	//libera a area do nodo
		      		if(digrafo == 0 && a != b){	//verifica se nao e' digrafo
						remove_aresta_l(g, b, a, 1);
					}
		      		return 1;   //removeu
		    	}
		 	}
		 	else{
		    	antes = ptr;		//anterior atualizado
		    	ptr = ptr->next;	//continua na lista	
		 	}
    	}

      return 0; //nao achou
  	
  	}

}

/*Funcao que busca se ha um elemento igual ao outro e chama a funcao de
remover o item, pois ele sera adicionado novamente com outro peso
grafo_l* g = grafo
int a = origem da aresta
int b = destino da aresta
int digrafo = se e' digrafo ou nao
*/
void busca_igual(grafo_l* g, int a, int b, int digrafo){

	node* m = (node*)calloc(1, sizeof(node));		//auxiliar
	m = g[a].list;

	if(m->next != NULL)
		m = m->next;

	if(m->info == b){
		remove_aresta_l(g, a, b, digrafo);
		return;
	}

	while(m->next != NULL){
		if(m->info == b){
			remove_aresta_l(g, a, b, digrafo);
			return;
		}
		m = m->next;
	}

	if(m->info == b){
		remove_aresta_l(g,a,b,digrafo);
		return;
	}

	return;

}

/*Funcao que cria uma aresta com base na entrada dada
grafo_l* g = grafo
int a = origem da aresta
int b = destino da aresta
int digrafo = se e' digrafo ou nao
*/
void cria_aresta_la(grafo_l* g, int a, int b, int c, int digrafo){

	node* n = (node*)calloc(1, sizeof(node));		//auxiliar
	n = g[a].list;

	node* m = (node*)calloc(1, sizeof(node));		//atual
	node* o = (node*)calloc(1, sizeof(node));		//anterior

	o = NULL;

	m->info = b;
	m->peso = c;
	m->next = NULL;

	busca_igual(g, a, b, digrafo);

	if(o == NULL){
		/*procura posicao para insercao*/
		while(n != NULL && n->info < b){
			o = n;
			n = n->next;
		}

		/*insere elemeto*/
		//começo
		if(g[a].list->next == NULL){
			g[a].list->next = m;
			m->next = NULL;
		}
		else{
			o->next = m;
			m->next = n;
		}
	}
	else{
		o->peso = c;
	}

	//se nao foir digrafo e' necessario que a funcao seja chamada novamente
	if(digrafo == 0 && a != b){
		cria_aresta_la(g, b, a, c, 1);
	}

	return;

}

/*preenche os grafos inicialmente com a entrada dada utilizando a funcao de insercao
grafo_l* g = grafo
int aresta = numero de arestas
int** arestas = origem e destino das arestas
int digrafo = se e' digrafo ou nao
*/
void preenche_inicial_l(grafo_l* g, int aresta, int** arestas, int digrafo){

	for(int cont = 0; cont < aresta; cont++){
		cria_aresta_la(g, arestas[cont][0], arestas[cont][1], arestas[cont][2], digrafo);
	}

}

/*preenche os grafos de forma trasposta seja digrafo
grafo_l* g = grafo
int aresta = numero de arestas
int** arestas = origem e destino das arestas
int digrafo = se e' digrafo ou nao
*/
void preenche_inicial_la(grafo_l* g, int aresta, int** arestas, int digrafo){

	for(int cont = 0; cont < aresta; cont++){
		cria_aresta_la(g, arestas[cont][1], arestas[cont][0], arestas[cont][2], digrafo);
	}

}

/*acha o menor peso dentre os grafos
grafo_l* g = grafo
int m = numero de vertices
int digrafo = se e' digrafo ou nao
*/
void acha_menor_l(grafo_l* g, int m, int digrafo){

	int menor = 10000;		//coloca um numero grande para facilitar a procura do menor
	int vertice1;
	int vertice2;

	node* n = (node*)calloc(1, sizeof(node));		//auxiliar
	
	for(int cont = 0; cont < m; cont++){
		n = g[cont].list;
		if(n->next != NULL)
			n = n->next;
		while(n != NULL){
			if(n->peso < menor){
				menor = n->peso;
				vertice1 = cont;
				vertice2 = n->info;
			}
			n = n->next;
		}
	}

	if(vertice1 > vertice2 && digrafo == 0){
		int aux = vertice1;
		vertice1 = vertice2;
		vertice2 = aux;
	}

	printf("%d %d\n", vertice1, vertice2);

}

/*imprime os grafos
grafo_l* g = grafo
int m = numero de vertices
*/
void imprime_grafo_l(grafo_l* g, int m){

	node* n = (node*)calloc(1, sizeof(node));		//auxiliar
	node* o = (node*)calloc(1, sizeof(node));		//anterior

	int entrou = 0;

	for(int cont = 0; cont < m; cont++){
		n = g[cont].list->next;
		if(n->peso != -1){
			printf("%d. ", cont);
		
			if(n->next == NULL && n->peso != -1){
				printf("%d(%d) ", n->info, n->peso);
				printf("\n");
				continue;
			}
			while(n->next != NULL){
				printf("%d(%d) ", n->info, n->peso);
				o = n;
				n = n->next;
				entrou = 1;
			}
			if(entrou == 1){
				printf("%d(%d) ", n->info, n->peso);
			}
		}
		printf("\n");
	}

}

/*imprime os adjacentes ao vertice
grafo_l* g = grafo
int vertice = o veritce que deseja imprimir os adjacentes
*/
void imprime_vertice_l(grafo_l* g, int vertice){

	node* n = (node*)calloc(1, sizeof(node));		//auxiliar
	n = g[vertice].list; 

	if(n->next != NULL){
		n = n->next;
	}

	if(n->next != NULL && n->peso != -1){
		if(n->next == NULL)
			printf("%d\n", n->info);
		else{
			while(n->next != NULL){
				printf("%d ", n->info);
				n = n->next;
			}
			printf("%d ", n->info);
		}
	}
	printf("\n");

}

/*Funcao que destroi as listas de adjacencia do grafo
grafo_l* g = grafo
int vertice = numero de vertices
*/
void destroi_lista(grafo_l* g, int vertice){

	for(int cont = 0; cont < vertice; cont++){

		node* prox;
		node* atual;

		atual = g[cont].list;
		while(atual != NULL){
			prox = atual->next;
			free(atual);
			atual = prox;
		}

	}

}