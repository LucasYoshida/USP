/*
***************************************************

	USP - ICMC
	Algoritmos e Estruturas de Dados I - 2017
	
	Trabalho 1 - Calculadora de Expressoes Aritmeticas

	Outubro - 2017

	Lucas Noriyuki Yoshida - 10262586

***************************************************
*/

/*Funcao que transforma um numero em char para um numero em double
Retorno:
	double == o proprio numero
Parametros:
	char* numero == o numero em formato de caracteres tipo char
*/
double chardouble(char* numero);

/*Funcao que transforma um numero double para um vetor de caracteres
Retorno:
	void
Parametros:
	double numero == o numero para traasnformar
	char* novo == vetor que armazena o novo numero
*/
void doublechar(double numero, char* novo);

/*Funcao que faz a conta pedida
Retorno:
	double == o resultado da conta
Parametros:
	double a == primeiro numero
	double b == segundo numero
	char op == operacao
*/
double fazconta(double a, double b, char op);

/*Funcao que soluciona expresssao em notacao polonesa
Retorno:
	int == '0' nao tem erro '1' tem erro
Parametros:
	char* output == guarda a expressao em notacao polonesa
	double* resposta == guarda a resposta da expressao
*/
int solucao(char* output, double* resposta);

/*Funcao que verifica se a operacao tem uma prioridade menor ou igual a da stack
Retorno:
	int == '0' se falso '1' se verdadeiro
Parametros:
	char a == primeira operacao
	char b == segunda operacao
*/
int verifica (char a, char b);

/*Funcao que transforma a expressao de notacao convencional para polonesa
Retorno:
	int == '0' nao deu erro '1' deu erro
Parametros:
	char* expressoes == uma expressao do problema
	char* output == serve para guardar a notacao polonesa
					as chaves '[]' servem para identificar
					o tamanho de cada numero ou operacao
*/
int transforma(char* expressoes, char* output);