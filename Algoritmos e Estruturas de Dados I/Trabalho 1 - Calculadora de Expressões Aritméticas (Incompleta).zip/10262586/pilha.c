/*
***************************************************

	USP - ICMC
	Algoritmos e Estruturas de Dados I - 2017
	
	Trabalho 1 - Calculadora de Expressoes Aritmeticas

	Outubro - 2017

	Lucas Noriyuki Yoshida - 10262586

***************************************************
*/
#include <stdio.h>
#include <pilha.h>

//struct relacionada a uma pilha/stack
typedef struct stack{

	int topo;			//guarda o topo da stack
	char* stack;		//a propria pilha

} pilha;

/*Funcao que empilha um caracter numa pilha
Retorno:
	void
Parametros:
	pilha* oi		//uma pilha qualquer
	char ola		//caracter qualquer
*/
void push(pilha* oi, char ola){

	oi->stack[oi->topo] = ola;
	oi->topo++;

}

/*Funcao que desempilha um caracter numa pilha
Retorno:
	char			//retorna o caracter desempilhado
Parametros:
	pilha* oi		//uma pilha qualquer
*/
char pop(pilha* oi){

	char aux;		//auxilia no retorno

	aux = oi->stack[oi->topo - 1];
	//printf("auxaaaa -> %c\n", aux);
	oi->stack[oi->topo] = '0';
	oi->topo--;

	return aux;

}