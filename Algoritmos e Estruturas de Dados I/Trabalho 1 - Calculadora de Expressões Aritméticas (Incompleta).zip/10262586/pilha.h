/*
***************************************************

	USP - ICMC
	Algoritmos e Estruturas de Dados I - 2017
	
	Trabalho 1 - Calculadora de Expressoes Aritmeticas

	Outubro - 2017

	Lucas Noriyuki Yoshida - 10262586

***************************************************
*/

/*Funcao que empilha um caracter numa pilha
Retorno:
	void
Parametros:
	pilha* oi		//uma pilha qualquer
	char ola		//caracter qualquer
*/
void push(pilha* oi, char ola);

/*Funcao que desempilha um caracter numa pilha
Retorno:
	char			//retorna o caracter desempilhado
Parametros:
	pilha* oi		//uma pilha qualquer
*/
char pop(pilha* oi);