/*
***************************************************

	USP - ICMC
	Algoritmos e Estruturas de Dados I - 2017
	
	Trabalho 1 - Calculadora de Expressoes Aritmeticas

	Outubro - 2017

	Lucas Noriyuki Yoshida - 10262586

***************************************************
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "pilha.h"

/*Funcao que transforma um numero em char para um numero em double
Retorno:
	double == o proprio numero
Parametros:
	char* numero == o numero em formato de caracteres tipo char
*/
double chardouble(char* numero){

	double num = 0;					//armazena o numero para saida
	int aux = 0;					//auxilia com o calculo
	char antes[100] = {0};				//antes da virgula
	char depois[100] = {0};				//depois da virgula
	int ponto = 0;					//flag que indica se o numero tem dicimal

	for(int cont = 0; cont < strlen(numero); cont++){
		if(numero[cont] == '.'){
			ponto = 1;
			aux = 0;
		}
		if(ponto == 0){
			antes[aux] = numero[cont];
			aux++;
		}
		if(cont + 1 < strlen(numero) && ponto == 1){
			//printf("entrou %d\n", cont);
			depois[aux] = numero[cont + 1];
			aux++;
		}
	}

	aux = strlen(antes);

	//transforma o numero antes da virgula em double
	for(int cont = 0; cont < strlen(antes); cont++){
		double ajuda = num;					//ajuda a calcular
		int n = ((int)antes[cont] - 48);	//ajuda a calcular
		num = n * pow(10, aux - 1);
		//printf("1aux -> %d num -> %c %.2lf\n", aux - 1, antes[cont], num);
		num += ajuda;
		aux--;
	}

	//transforma o numero depois da virgula em double
	if(ponto == 1){
		for(int cont = 0; cont < strlen(depois); cont++){
			double ajuda = num;					//ajuda a calcular
			int n = ((int)depois[cont] - 48);	//ajuda a calcular
			num = n * pow(10, -(cont + 1));
			//printf("aux -> %d num -> %c %.2lf\n", -(cont + 1), depois[cont], num);
			num += ajuda;
			//printf("numcarai %lf\n", num);
			aux--;
		}
	}
	//printf("resultado parcial %lf\n", num);

	return num;

}

/*Funcao que transforma um numero double para um vetor de caracteres
Retorno:
	void
Parametros:
	double numero == o numero para traasnformar
	char* novo == vetor que armazena o novo numero
*/
void doublechar(double numero, char* novo){

	int cont = 0;			//ajuda na contagem do novo vetor
	char antes[100] = {0};	//antes da virgula
	char depois[100] = {0};	//depois da virgula

	//verifica se tem numero depois da virgula
	//caso tenha
	if((int)numero != ceil(numero)){
		float n = numero - (int)numero;
		//printf("n -> %lf\n", n);
		while(n != ceil(n)){
			//printf("%lf %lf\n", n, ceil(n));
			depois[cont] = (n*10.0)+48;
			cont++;
			n = n * 10.0;
			//printf("dentro n -> %lf\n", n);
		}
		//printf("depois -> %s\n", depois);
		cont = 0;
		//pega o arredondamento para baixo para fazer a parte inteira
		int aux1 = (int)floor(numero);
		//printf("aux1 -> %d\n", aux1);
		while(aux1!= 0){
			antes[cont] = (aux1 % 10) + 48;
			cont++;
			aux1 = aux1 / 10; 
		}
		//printf("antes -> %s\n", antes);
		cont = 0;
		for(int cont1 = strlen(antes) - 1; cont1 >= 0; cont1--){
			novo[cont] = antes[cont1];
			cont++;
		}
		novo[cont] = '.';
		cont++;
		for(int cont1 = 0; cont1 < strlen(depois); cont1++){
			novo[cont] = depois[cont1];
			cont++;
		}
	}
	//caso nao tenha
	else{
		int aux1 = (int)numero;
		cont = 0;
		while(aux1 != 0){
			novo[cont] = (aux1 % 10)+48;
			aux1 = aux1 / 10; 
			cont++;
		}	
	}

	//printf("NOVO -> %s\n", novo);

}

/*Funcao que faz a conta pedida
Retorno:
	double == o resultado da conta
Parametros:
	double a == primeiro numero
	double b == segundo numero
	char op == operacao
*/
double fazconta(double a, double b, char op){

	if(op == '+'){
		return a + b;
	}
	else if(op == '-'){
		return a - b;
	}
	else if(op == '*'){
		return a * b;
	}
	else if(op == '/'){
		return a / b;
	}

	return 0;

}

/*Funcao que soluciona expresssao em notacao polonesa
Retorno:
	int == '0' nao tem erro '1' tem erro
Parametros:
	char* output == guarda a expressao em notacao polonesa
	double* resposta == guarda a resposta da expressao
*/
int solucao(char* output, double* resposta){

	char** secciona;		//secciona o vetor em numeros e expressoes menores
	char** calcula;			//ajuda a calcular
	double resul = 0;		//guarda o resultado parcial

	secciona = (char**)calloc(1000, sizeof(char*));
	for(int cont = 0; cont < 1000; cont++){
		secciona[cont] = (char*)calloc(1000, sizeof(char));
	}

	calcula = (char**)calloc(1000, sizeof(char*));
	for(int cont = 0; cont < 1000; cont++){
		calcula[cont] = (char*)calloc(1000, sizeof(char));
	}

	//printf("%s\n", output);

	int cont1 = 0;		//ajuda na contagem das linhas de secciona
	int cont2 = 0;		//ajuda na contagem das colunas de secciona
	int ajuda = 0;		//ajuda percorrer o output e depois ajuda para formar uma especie de pilha

	//secciona o vetor output em pequenas strings para facilitar a contagem
	for(int cont = 0; cont < strlen(output); cont++){
		if(output[cont] == '['){
			cont2 = 0;
			secciona[cont1][cont2] = output[cont+1];
			//printf("cont -> %d, %c\n", cont, secciona[cont1][cont2]);
			cont2++;
			ajuda = 1;
		}
		if(output[cont+1] == ']'){
			cont1++;
			ajuda = 0;
		}
		else if (ajuda > 1){
			secciona[cont1][cont2] = output[cont+1];
			//printf("cont1 -> %d, %c\n", cont, secciona[cont1][cont2]);
			cont2++;
		}
		ajuda++;
	}
	for(int cont = 0; cont < cont1; cont++){
		//printf("%s\n", secciona[cont]);
	}

	ajuda = 0;

	//calculando a expressao (como se fosse uma pilha)
	for(int cont = 0; cont < cont1 ; cont++){
		if(secciona[cont][0] == '+' || secciona[cont][0] == '/' || secciona[cont][0] == '-' || secciona[cont][0] == '*'){
			char a[100];		//primeiro numero
			char b[100];		//segundo numero
			ajuda--;
			strcpy(b, calcula[ajuda]);
			ajuda--;
			strcpy(a, calcula[ajuda]);
			double primeiro = chardouble(a);
			//printf("a -> %s, %lf\n", a, primeiro);
			double segundo = chardouble(b);
			//printf("b -> %s, %lf\n", b, segundo);
			if (segundo == 0 && secciona[cont][0] == '/'){
				return 1;
			}
			resul = fazconta(primeiro, segundo, secciona[cont][0]);
			//printf("%lf\n", resul);
			if(ajuda == 0 && cont == cont1 - 1){
				*resposta = resul;
				return 0;
			}
			else{
				doublechar(resul, calcula[ajuda]);
				ajuda++;
			}
		}
		else{
			strcpy(calcula[ajuda], secciona[cont]);
			ajuda++;
		}
	}

	for(int cont = 0; cont < 1000; cont++){
		free(secciona[cont]);
	}
	free(secciona);

	for(int cont = 0; cont < 1000; cont++){
		free(calcula[cont]);
	}
	free(calcula);

	*resposta = resul;

	return 0;

}

/*Funcao que verifica se a operacao tem uma prioridade menor ou igual a da stack
Retorno:
	int == '0' se falso '1' se verdadeiro
Parametros:
	char a == primeira operacao
	char b == segunda operacao
*/
int verifica (char a, char b){

	if(a == '+'){
		if(b == '-' || b == '+'){
			return 1;
		}
		else if(b == '*' || b == '/'){
			return 1;
		}
	}
	if(a == '-'){
		if(b == '+' || b == '-'){
			return 1;
		}
		else if (b == '*' || b == '/'){
			return 1;
		}
	}
	if(a == '*'){
		if(b == '*' || b == '-' || b == '+' || b == '/'){
			return 0;
		}
		else{
			return 0;
		}
	}
	if(a == '/'){
		if(b == '*' || b == '-' || b == '+' || b == '/'){
			return 0;
		}
		else{
			return 0;
		}
	}

	return 0;

}

/*Funcao que transforma a expressao de notacao convencional para polonesa
Retorno:
	int == '0' nao deu erro '1' deu erro
Parametros:
	char* expressoes == uma expressao do problema
	char* output == serve para guardar a notacao polonesa
					as chaves '[]' servem para identificar
					o tamanho de cada numero ou operacao
*/
int transforma(char* expressoes, char* output){

	int erro = 0;		//informa se deu erro ou nao
	int aux = 0;		//ajuda a guardar no output
	pilha operacoes;	//guarda as operacoes
	operacoes.topo = 0;	//inicializa topo
	int ajuda = 0;		//ajuda a verificar o tamanho do numero
	int ajuda1 = 0;		//ajuda a verificar o tamanho do numero tambem

	operacoes.stack = (char*)calloc(1000, sizeof(char));

	for(int cont = 0; cont < strlen(expressoes); cont++){
		//se e' um numero
		if(expressoes[cont] != '-' && expressoes[cont] != '+' && expressoes[cont] != '/' && expressoes[cont] != '*' && expressoes[cont] != '(' && expressoes[cont] != ')'){
			if(ajuda1 < 1){
				output[aux] = '[';
				aux++;
			}
			ajuda = 1;
			ajuda1 = 1;
			output[aux] = expressoes[cont];
			aux++;
			if(cont == strlen(expressoes) -1){
				output[aux] = ']';
				aux++;
			}
			//printf("aux -> %d numero -> %c output -> %s\n", aux, output[aux], output);
		}
		//se e' uma operacao
		else if(expressoes[cont] != '(' && expressoes[cont] != ')'){
			if(ajuda == 1){
				output[aux] = ']';
				aux++;
				ajuda1 = 0;
			}
			ajuda = 2;
			//printf("operacoes1 -> %s expressa -> %c\n", output, expressoes[cont]);
			if(verifica (expressoes[cont], operacoes.stack[operacoes.topo - 1])){
				output[aux] = '[';
				aux++;
				output[aux] = pop(&operacoes);
				aux++;
				output[aux] = ']';
				//printf("fez pop operacoes2 -> %s aux -> %d\n", output, aux);
				aux++;
			}
			push(&operacoes, expressoes[cont]);
			//printf("push feito -> %c %d\n", operacoes.stack[operacoes.topo - 1], operacoes.topo);;
		}
		//se e' '('
		else if (expressoes[cont] == '('){
			if(ajuda == 1){
				output[aux] = ']';
				aux++;
				ajuda1 = 0;
			}
			ajuda = 2;
			push(&operacoes, expressoes[cont]);
		}
		//se e' ')'
		else {
			if(ajuda == 1){
				output[aux] = ']';
				aux++;
				ajuda1 = 0;
			}
			ajuda = 2;
			while(operacoes.stack[operacoes.topo - 1] != '('){
				//printf("dentro dos ()\n");
				output[aux] = '[';
				aux++;
				output[aux] = pop(&operacoes);
				aux++;
				output[aux] = ']';
				aux++;
			}
			//printf("retirou o (\n");
			pop(&operacoes);
		}
		//printf("cont -> %d topo -> %d stack -> %s output-> %s\n", cont, operacoes.topo, operacoes.stack, output);
	}

	//desempilha o resto da pilha
	while(operacoes.topo -1 >= 0){
		output[aux] = '[';
		aux++;
		output[aux] = pop(&operacoes);
		aux++;
		output[aux] = ']';
		aux++;
	}

	if(ajuda == 1){
		output[aux] = ']';
		aux++;
	}

	ajuda = 2;

	//printf("stack -> %s output -> %s\n",operacoes.stack, output);

	for(int cont = 0; cont < strlen(output); cont++){
		if(output[cont] == '('){
			erro = 1;
		}
	}

	free(operacoes.stack);

	return erro;

}