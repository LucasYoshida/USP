/*
***************************************************

	USP - ICMC
	Algoritmos e Estruturas de Dados I - 2017
	
	Trabalho 1 - Calculadora de Expressoes Aritmeticas

	Outubro - 2017

	Lucas Noriyuki Yoshida - 10262586

***************************************************
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "caluladora.h"

//************************************************
int main (){

	char** expressoes;	//guarda as expressoes do problema
	int n = 0;			//guarda o numero de expressoes
	int erro = 0;		//indica se tem erro ou nao
	double resposta;	//guarda a resposta encontrada

	//alocacao
	expressoes = (char**)calloc(1000, sizeof(char*));
	for(int cont = 0; cont < 1000; cont++){
		expressoes[cont] = (char*)calloc(1000, sizeof(char));
	}

	for(int cont = 0; cont < 1000; cont++){
		//entrada das expressoes
		fgets(expressoes[cont], 1000, stdin);
		//retira os espaços
		for(int cont1 = 0; cont1 < strlen(expressoes[cont]); cont1++){
			if(expressoes[cont][cont1] == ' '){
				for(int cont2 = cont1 + 1; cont2 <= strlen(expressoes[cont]); cont2++){
					expressoes[cont][cont2-1] = expressoes[cont][cont2];
				}
			}
		}
		//verifica a parada
		if(expressoes[cont][strlen(expressoes[cont])-2] == ';'){
			break;
		}
		//retira a quebra de linha e o ','
		expressoes[cont][strlen(expressoes[cont])-2] = '\0';
		//printf("%s\n", expressoes[cont]);
		n++;
	}
	//retira o ';' da ultima expressao
	expressoes[n][strlen(expressoes[n])-2] = '\0';

	for(int cont = 0; cont <= n; cont++){
		char* output;		//guarda em notacao polonesa
		output = (char*)calloc(1000, sizeof(char));
		erro = transforma(expressoes[cont], output);
		if(erro > 0){
			printf("Expressao incorreta\n");
		}
		else{
			erro = solucao(output, &resposta);
			if(erro > 0){
				printf("Expressao incorreta\n");
			}
			else{
				printf("%.2f\n", resposta);
			}
		}
		free(output);
	}

	//free
	for(int cont = 0; cont < 1000; cont++){
		free(expressoes[cont]);
	}
	free(expressoes);

	return 0;

}