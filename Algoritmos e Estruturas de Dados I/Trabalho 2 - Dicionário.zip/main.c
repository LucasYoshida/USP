/*
***************************************************

	USP - ICMC
	ALG1 - 2017
	
	Trabalho 2 - Dicionario

	Outubro - 2017

	Lucas Noriyuki Yoshida - 10262586

****************************************************
*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include "dicionario.h"

int main () {

	char** entrada;			//entrada das operacoes
	t_lista* listas = NULL;	//listas para a skiplist			
	t_lista* inicio = NULL;	//marca o inicio da skiplist
  	srand(time(NULL));		//gera nova seed

  	char* operacao = calloc(13, sizeof(char));		//guarda a operacao
	char* palavra = calloc(53, sizeof(char));		//guarda a palavra/verbete
	char* definicao = calloc(143, sizeof(char));	//guarda a definicao

	//cria as listas dos niveis da Skiplist com base no MaxLevel
	inicio = criaSkiplist(listas);

	while(scanf("%s", operacao) != EOF){
		
		scanf("%s", palavra);

		t_lista* achou = NULL;		//NULL = nao encontrado ALGO = encontrado
		int aleat = 0;				//numero aleatorio gerado pra insercao

		//insercao
		if(operacao[0] == 'i' && operacao[1] == 'n'){
			
			getchar();
			fgets(definicao, 143, stdin);
			if(definicao[strlen(definicao) - 1] == '\n'){
				definicao[strlen(definicao) - 1] = '\0';
			}

			//aqui faz o numero aleatorio para colocar no nivel da skiplist
			while(rand() % 2 && aleat <= MaxLevel)
				aleat++;

			achou = buscaSkiplist(inicio, palavra);

			if(achou == NULL){
			  insereSkiplist(inicio, aleat, palavra, definicao);
			}
			else
				printf("OPERACAO INVALIDA\n");
		}
		//remocao
		else if(operacao[0] == 'r'){

			achou = buscaSkiplist(inicio, palavra);

			if(achou != NULL){
				removeSkiplist(achou, palavra);
			}
			else
				printf("OPERACAO INVALIDA\n");
		}
		//busca
		else if(operacao[0] == 'b'){

			achou = buscaSkiplist(inicio, palavra);

			if(achou != NULL)
				printf("%s %s\n", achou->palavra, achou->definicao);
			else
				printf("OPERACAO INVALIDA\n");
		}
		//alteracao
		else if(operacao[0] == 'a'){

			achou = buscaSkiplist(inicio, palavra);

			getchar();
			fgets(definicao, 143, stdin);
			if(definicao[strlen(definicao) - 1] == '\n'){
				definicao[strlen(definicao) - 1] = '\0';
			}

			if(achou != NULL){
				alteraSkiplist(achou, definicao);
			}
			else
				printf("OPERACAO INVALIDA\n");	
		}
		//impressao
		else{

			achou = buscaImprime(inicio, palavra);

			if(achou != NULL)
				imprimeItens(achou);
			else
				printf("NAO HA PALAVRAS INICIADAS POR %c\n", palavra[0]);
		}
		
	}

	free(operacao);
	operacao = NULL;
	free(palavra);
	palavra = NULL;
	free(definicao);
	definicao = NULL;

	eliminaSkiplist(inicio);

}