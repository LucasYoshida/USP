/*
***************************************************

	USP - ICMC
	ALG1 - 2017
	
	Trabalho 2 - Dicionario

	Outubro - 2017

	Lucas Noriyuki Yoshida - 10262586

****************************************************
*/
	
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include "dicionario.h"

//*****************TAD SKIPLIST****************************

/*Funcao que inicia as listas que serao utilizadas como skiplist
Retorno:
	t_lista* = onde fica o inicio da skiplist
Parametros:
	t_lista* A = um no' de uma lista
*/
t_lista* criaSkiplist(t_lista* A){

	t_lista* aux = NULL;
	t_lista* inicio = NULL;

	//cria listas ate o MaxLevel
	for(int cont = MaxLevel; cont >= 0; cont--){
		A = (t_lista*)calloc(1, sizeof(t_lista));
		A->nivel = cont;
		A->palavra = (char*)calloc(53, sizeof(char));
		A->definicao = (char*)calloc(143, sizeof(char));
		if(cont != MaxLevel)
			aux->baix = A;
		if(cont == MaxLevel)
			inicio = A;
		aux = A;
		A = A->baix;
	}
	return inicio;
}

/*Funcao que insere um item na lista na posicao que e' passada
Retorno:
	void
Parametros:
	t_lista* A = ponteiro do local onde quer inserir (proxima posicao)
*/
void insereLista(t_lista* A, char* str1, char* str2){

	t_lista* B = NULL;

	B = (t_lista*)calloc(1, sizeof(t_lista));
	B->palavra = (char*)calloc(53, sizeof(char));
	B->definicao = (char*)calloc(143, sizeof(char));
	B->nivel = A->nivel;

	strcpy(B->palavra, str1);
	strcpy(B->definicao, str2);

	B->ant = A;
	if(A->prox != NULL){
		B->prox = A->prox;
		A->prox->ant = B;
	}
	else
		B->prox = NULL;
	A->prox = B;
	

}

/*Funcao que imprime a skiplist inteira
Retorno:
	void
Parametros:
	t_lista* inicio = inicio da skiplist
*/
void imprimeSkiplist(t_lista* inicio){

	t_lista* aux = inicio;

  	for(int cont = MaxLevel; cont >= 0; cont--){
		printf("---- %d ----\n", aux->nivel);
		while(aux->prox != NULL){
			aux = aux->prox;
			printf("%s ", aux->palavra);
		}
		while(aux->ant != NULL){
			aux = aux->ant;
		}
		printf("\n");
		aux = aux->baix;
	}

}

/*Funcao que busca um item na skiplist
Retorno:
	t_lista* = NULL (nao encontrado), endereco do achado (encontrado)
Parametros:
	t_lista* inicio = guarda o inicio da skiplist
	char* str1 = verbete/palavra
*/
t_lista* buscaSkiplist(t_lista* inicio, char* str1){

	t_lista* aux = inicio;

	while(aux != NULL){
		if(aux->prox != NULL && strcmp(str1, aux->prox->palavra) == 0){
			return aux->prox;
		}
		else if(aux->prox == NULL || strcmp(str1, aux->prox->palavra) < 0){
			aux = aux->baix;
		}
		else if(strcmp(str1, aux->prox->palavra) > 0){
			aux = aux->prox;
		}
	}

	return NULL;

}

/*Funcao que insere um item na skiplist
Retorno:
	void
Parametros:
	t_lista* inicio = inicio da skiplist
	int aleat = numero aleatorio para o nivel a ser colocado
	char* str1 = verbete/palavra
	char* str2 = definicao
*/
void insereSkiplist(t_lista* inicio, int aleat, char* str1, char* str2){

	t_lista* aux = inicio;	//auxilia na passagem pela skiplist
	int inseriu = 0;		//0 = nao inseriu, 1 = inseriu
	t_lista* aqui = NULL;	//ultimo lugar que foi inserido (auxilia quando for indicar o ->baix)
	int comeco = aleat;		//comeco para inserir na Skiplist

	//faz desde o nivel mais alto (MaxLevel), como se fosse uma busca até encontrar o nivel para inserir
	for(int cont = MaxLevel; cont >= 0; cont--){
		inseriu = 0;
		if(aux->nivel == aleat && (aux->prox == NULL || strcmp(str1, aux->prox->palavra) < 0)){
			insereLista(aux, str1, str2);
			if(cont != comeco)
				aqui->baix = aux->prox;
			aqui = aux->prox;
			aux = aux->baix;
			aleat--;
		}
		else if(aux->nivel == aleat && (strcmp(str1, aux->prox->palavra) > 0)){
		  	aux = aux->prox;
			while(inseriu != 1){
				if(aux->prox == NULL || strcmp(str1, aux->prox->palavra) < 0){
					insereLista(aux, str1, str2);
					inseriu = 1;
					if(cont != comeco)
			      		aqui->baix = aux->prox;
					aqui = aux->prox;
					aux = aux->baix;
					aleat--;
					break;
				}
				else
					aux = aux->prox;
			}
		}
		//enquanto aux->nivel != aleat faz um tipo de busca té chegar no nivel requerido por aleat
		else if(aux->nivel != aleat && (aux->prox == NULL || strcmp(str1, aux->prox->palavra) < 0)){
			aux = aux->baix;
		}
		else if(aux->nivel != aleat && (strcmp(str1, aux->prox->palavra) > 0)){
		  	aux = aux->prox;
		  	while(inseriu != 1){
				if(aux->prox == NULL || strcmp(str1, aux->prox->palavra) < 0){
					aux = aux->baix;
					inseriu = 1;
					break;
				}
				else
					aux = aux->prox;
			}
		}
	}

}

/*Funcao que remove um item na skiplist
Retorno:
	void
Parametros:
	t_lista* pont = ponteiro que indica o lugar para remover
	char* str1 = palavra/verbete
*/
void removeSkiplist(t_lista* pont, char* str1){

	t_lista* aux = NULL;
  	int comeco = pont->nivel;

	for(int cont = comeco; cont >= 0; cont--){
		aux = pont;
		if(cont != 0)
			pont = pont->baix;
		aux->ant->prox = aux->prox;
		if(aux->prox != NULL)
			aux->prox->ant = aux->ant;
		free(aux->palavra);
		aux->palavra = NULL;
		free(aux->definicao);
		aux->definicao = NULL;
		free(aux);
		aux = NULL;
	}

}

/*Funcao que altera a definicao de um item da skiplist
Retorno:
	void
Parametros:
	t_lista* pont = ponteiro que indica o lugar para alterar
	char* str2 = definicao a ser trocada
*/
void alteraSkiplist(t_lista* pont, char* str2){

	for(int cont = pont->nivel; cont >= 0; cont--){
		strcpy(pont->definicao, str2);
		if(cont != 0)
			pont = pont->baix;
	}

}

/*Funcao que busca o primeiro item para ser impresso pelo funcao 'imprimi'
Retorno:
	t_lista* = NULL (nao encontrado), endereco do achado (encontrado)
Parametros:
	t_lista* inicio = inicio da skiplist
	char* chr1 = caracter para os verbetes serem impressos
*/
t_lista* buscaImprime(t_lista* inicio, char* chr1){

	t_lista* aux = inicio;

	int achou = 0;		//indica se achou uma palavra com o caracter

	//mesmo pensamento da buscaSkiplist, porem esta encontra a primeira palavra com o mesmo caracter requerido
	while(aux != NULL){
		if(aux->prox != NULL && chr1[0] == aux->prox->palavra[0]){
		 	aux = aux->prox;
		 	achou = 1;
		 	break;
		}
		else if(aux->prox == NULL || chr1[0] < aux->prox->palavra[0]){
			aux = aux->baix;
		}
		else if(chr1[0] > aux->prox->palavra[0]){
			aux = aux->prox;
		}
	}

	if(aux == NULL)
		return NULL;	
	
	//aqui vai até o nivel 0 (que possui todos os itens) depois volta até encontrar o primeiro item com aquele caracter
	int comeco = aux->nivel;
	for(int cont = comeco; cont > 0; cont--){
		aux = aux->baix;
	}
	while(aux->ant->palavra[0] == chr1[0]){
		aux = aux->ant;
	}
	return aux;

}

/*Funcao que imprimi todos verbetes que iniciam com o caracter chr1
Retorno:
	void
Parametros:
	t_lista* pont = ponteiro que indica o lugar para comecar a impressao
*/
void imprimeItens(t_lista* pont){

	while(1){
	  if(pont->prox != NULL && pont->prox->palavra[0] == pont->palavra[0]){
	    printf("%s %s\n", pont->palavra, pont->definicao);
		  pont = pont->prox;
  		}
  		else{
  			break;
  		}
	}
	printf("%s %s\n", pont->palavra, pont->definicao);
	
}

/*Funcao que elimina a skiplist
Retorno:
	void
Parametros:
	t_lista* inicio = ponteiro que indica o comeco da lista
*/
void eliminaSkiplist (t_lista* inicio){

	t_lista* aux = inicio;
	
	while(1){
		while(1){
  			if(aux->prox != NULL){
				aux = aux->prox;
		}
			else
				break;
		}
		while(1){
			if(aux->ant != NULL){
				t_lista* aux1 = aux;
				aux = aux->ant;
				free(aux1->palavra);
				aux1->palavra = NULL;
				free(aux1->definicao);
				aux1->definicao = NULL;
				free(aux1);
				aux1 = NULL;
			}
			else
				break;
		}
		if(aux->baix != NULL){
			t_lista* aux1 = aux;
			aux = aux->baix;
			free(aux1->palavra);
			aux1->palavra = NULL;
			free(aux1->definicao);
			aux1->definicao = NULL;
			free(aux1);
			aux1 = NULL;
		}
		else{
		  	free(aux->palavra);
			aux->palavra = NULL;
			free(aux->definicao);
			aux->definicao = NULL;
			free(aux);
			aux = NULL;
			break;
		}
	}

}