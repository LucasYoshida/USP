/*
***************************************************

	USP - ICMC
	ALG1 - 2017
	
	Trabalho 2 - Dicionario

	Outubro - 2017

	Lucas Noriyuki Yoshida - 10262586

****************************************************
*/

#ifndef _DICIONARIO_H_
#define _ DICIONARIO_H_

#define MaxLevel 30

struct no{

	char* palavra;		//guarda a palavra
	char* definicao;	//guarda a definicao
	int nivel;			//guarda o nivel
	struct no* ant;		//aponta para o item anterior
	struct no* prox;	//aponta para o item posterior
	struct no* baix;	//aponta para o item que vez na lista abaixo

};

//facilita na chamada
typedef struct no t_lista;

/*Funcao que inicia as listas que serao utilizadas como skiplist
Retorno:
	t_lista* = onde fica o inicio da skiplist
Parametros:
	t_lista* A = um no' de uma lista
*/
t_lista* criaSkiplist(t_lista* A);

/*Funcao que insere um item na lista na posicao que e' passada
Retorno:
	void
Parametros:
	t_lista* A = ponteiro do local onde quer inserir (proxima posicao)
*/
void insereLista(t_lista* A, char* str1, char* str2);

/*Funcao que imprime a skiplist inteira
Retorno:
	void
Parametros:
	t_lista* inicio = inicio da skiplist
*/
void imprimeSkiplist(t_lista* inicio);

/*Funcao que busca um item na skiplist
Retorno:
	t_lista* = NULL (nao encontrado), endereco do achado (encontrado)
Parametros:
	t_lista* inicio = guarda o inicio da skiplist
	char* str1 = verbete/palavra
*/
t_lista* buscaSkiplist(t_lista* inicio, char* str1);

/*Funcao que insere um item na skiplist
Retorno:
	void
Parametros:
	t_lista* inicio = inicio da skiplist
	int aleat = numero aleatorio para o nivel a ser colocado
	char* str1 = verbete/palavra
	char* str2 = definicao
*/
void insereSkiplist(t_lista* inicio, int aleat, char* str1, char* str2);

/*Funcao que remove um item na skiplist
Retorno:
	void
Parametros:
	t_lista* pont = ponteiro que indica o lugar para remover
	char* str1 = palavra/verbete
*/
void removeSkiplist(t_lista* pont, char* str1);

/*Funcao que altera a definicao de um item da skiplist
Retorno:
	void
Parametros:
	t_lista* pont = ponteiro que indica o lugar para alterar
	char* str2 = definicao a ser trocada
*/
void alteraSkiplist(t_lista* pont, char* str2);

/*Funcao que busca o primeiro item para ser impresso pelo funcao 'imprimi'
Retorno:
	t_lista* = NULL (nao encontrado), endereco do achado (encontrado)
Parametros:
	t_lista* inicio = inicio da skiplist
	char* chr1 = caracter para os verbetes serem impressos
*/
t_lista* buscaImprime(t_lista* inicio, char* chr1);

/*Funcao que imprimi todos verbetes que iniciam com o caracter chr1
Retorno:
	void
Parametros:
	t_lista* pont = ponteiro que indica o lugar para comecar a impressao
*/
void imprimeItens(t_lista* pont);

/*Funcao que elimina a skiplist
Retorno:
	void
Parametros:
	t_lista* inicio = ponteiro que indica o comeco da lista
*/
void eliminaSkiplist (t_lista* inicio);

#endif