/*
***************************************************

	USP - ICMC
	ALG1 - 2017
	
	Trabalho 3 - Arvores Balanceadas

	Novembro - 2017

	Lucas Noriyuki Yoshida - 10262586

****************************************************
*/

#include <stdio.h>
#include <stdlib.h>
#include "trb.h"

//**********************MAIN************************

int main() {

	char* N;		//numero de operacoes
	int op;		//guarda a operacao
	int valor;	//guarda o valor necessario para as operacoes: 1, 2 e 3
	t_tree* A;	//arvore balanceada
	int value;	//guarda o valor de maximo e minimo

	N = (char*)calloc(10, sizeof(N));

	scanf("%s", N);

	//inicializa a arvore
	A = NULL;
	A = initialize(A);

	//loop para a entrada das operacoes a serem feitas
	while(scanf("%d", &op) != EOF){
		
		int aux = 100;		//ajuda nas operacoes 2 e 3
		int find = 0;		//ajuda nas operacoes 2 e 3

		//insercao
		if(op == 1){
			//pega o espaco no buffer do teclado
			getchar();
			scanf("%d", &valor);
			insertion(&(*A), valor);
		}
		//sucessor
		else if(op == 2){
			//pega o espaco no buffer do teclado
			getchar();
			scanf("%d", &valor);
			//se 'valor' ja e' o maior dado entao o mesmo nao possui sucessor
			if(valor == findMax(A->root))
				printf("erro\n");
			else
				findSuccess(A->root, valor, &aux, &find);
		}
		//predecessor
		else if(op == 3){
			//pega o espaco no buffer do teclado
			getchar();
			scanf("%d", &valor);
			//se 'valor' ja e' o menor dado entao o mesmo nao possui antecessor
			if(valor == findMin(A->root))
				printf("erro\n");
			else
				findPrevious(A->root, valor, &aux, &find);
		}
		//maximo
		else if(op == 4){
			//verifica se nao tem filho a direita
			if(A->root->link[1] == NULL)
				printf("%d\n", A->root->data);
			else{
				value = findMax(A->root);
				printf("%d\n", value);
			}
		}
		//minimo
		else if(op == 5){
			//verifica se nao tem filho a esquerda
			if(A->root->link[0] == NULL)
				printf("%d\n", A->root->data);
			else{
				value = findMin(A->root);
				printf("%d\n", value);
			}
		}
		//pre ordem
		else if(op == 6){
			preOrder(A->root);
			printf("\n");
		}
		//em ordem
		else if(op == 7){
			inOrder(A->root);
			printf("\n");
		}
		//pos ordem
		else if(op == 8){
			posOrder(A->root);
			printf("\n");
		}
	}

	eliminateTree(A);
	free(N);

	return 0;

}