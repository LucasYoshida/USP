/*
***************************************************

	USP - ICMC
	ALG1 - 2017
	
	Trabalho 3 - Arvores Balanceadas

	Novembro - 2017

	Lucas Noriyuki Yoshida - 10262586

****************************************************
*/
#include <stdio.h>
#include <stdlib.h>

//'A' e' utilizado como se fosse um no' qualquer da arvore

//****************************************************

typedef struct node{

    int red;				//0 = preto e 1 = vermelho
    int data;				//dado da arvore
    struct node *link[2];	//apontadores para os filhos do no'

} t_node;
//utiliza um vetor de apontadores em vez de left/right 
//para facilitar o acesso pelas funcoes posteriores
//precisando apenas de duas funcoes para a rotacao
//sendo 0 = left e 1 = right ao comparar com os outros

typedef struct tree{

    t_node *root;			//guarda a raiz da arvore

} t_tree;

//**************************************************

/*Funcao que inicializa a arvore
Retorno:
	t_tree* = a propria arvore a ser criada
Parametros:
	t_tree* A = a arvore a ser inicializada
*/
t_tree* initialize(t_tree* A);

/*Funcao que serve para criar um novo no' na arvore
Retorno:
	t_node* = o novo no' da arvore
Parametros:
	int data = dado a ser colocado na arvore
*/
t_node* makeNode(int data);

/*Funcao auxiliar que indica se o no' e' vermelho ou nao e com isso auxilia na decisao das direcoes para as rotacoes
Retorno:
	int = 1 se e' vermelho ou 0 se e' preto
Parametros:
	t_node* A = no de uma arvore a ser verificado
*/ 
int isRed(t_node* A);

/*Funcao que faz a simples\uma vez rotacao para que a arvore esteja devidamente balanceada
Retorno:
	t_node* = o novo no' salvo que ajudou na rotacao
Parametros:
	t_node* A = no' a ser trabalhado a rotacao
	int dir = ajuda na direcao da rotacao(se e' esquerda ou direita)
*/
t_node* rotSingle(t_node* A, int dir);

/*Funcao que faz a simples\uma vez rotacao para que a arvore esteja devidamente balanceada
Retorno:
	t_node* = o novo no' salvo que ajudou na rotacao pela rotSingle
Parametros:
	t_node* A = no' a ser trabalhado a rotacao
	int dir = ajuda na direcao da rotacao(se e' esquerda ou direita, nesse caso a rotacao eh pelo menos uma vez para cada direcao) 
*/
t_node* rotDouble(t_node *A, int dir);

/*Funcao que insere um dado na arvore e ainda faz os ajustes necessarios para deixar a mesma balanceada
Retorno:
	t_node* = o ultimo no' alocado na arvore que compoe a mesma
Parametros:
	t_node* A = na primeira chamada e' a raiz da arvore depois passa a ser um de seus no's
	int data = dado a ser colocado na arvore
*/ 
t_node* insertData(t_node* A, int data);

/*Funcao que chama a insertData que faz a insercao, sendo esta para auxiliar pois e' repassada a raiz da arvore (que a mesma e' atualizada posteriormente)
Retorno:
	void
Parametros:
	t_tree* tree = arvore principal a ser atualizada
	int data = dado a ser incluido na arvore
*/
void insertion(t_tree* tree, int data);

/*Funcao que acha o sucessor de um numero que esta inserido na arvore (verificado previamente)
Retorno:
	void
Parametros:
	t_node* A = na primeira chamada e' a raiz da arvore depois passa a ser um de seus no's
	int data = dado a ser encontrado o sucessor
	int* aux = ajuda na procura do sucessor de data
	int* find = 1 se ja achou ou 0 se ainda nao achou
*/
void findSuccess(t_node* A, int data, int* aux, int* find);

/*Funcao que acha o precessor de um numero que esta inserido na arvore (verificado previamente)
Retorno:
	void
Parametros:
	t_node* A = na primeira chamada e' a raiz da arvore depois passa a ser um de seus no's
	int data = dado a ser encontrado o sucessor
	int* aux = ajuda na procura do sucessor de data
	int* find = 1 se ja achou ou 0 se ainda nao achou
*/
void findPrevious(t_node* A, int data, int* aux, int* find);

/*Funcao que encontra o no' que contem o dado de maior valor na arvore
Retorno:
	int = o proprio numero a ser encontrado
Parametros:
	t_node* A = na primeira chamada e' a raiz da arvore depois passa a ser um de seus no's
*/
int findMax (t_node *A);

/*Funcao que encontra o no' que contem o dado de menor valor na arvore
Retorno:
	int = o proprio numero a ser encontrado
Parametros:
	t_node* A = na primeira chamada e' a raiz da arvore depois passa a ser um de seus no's
*/
int findMin (t_node *A);

/*Funcao que faz o percurso de pre-ordem na arvore
Retorno:
	void
Parametros:
	t_node* A = na primeira chamada e' a raiz da arvore depois passa a ser um de seus no's
*/
void preOrder(t_node *A);

/*Funcao que faz o percurso de em-ordem na arvore
Retorno:
	void
Parametros:
	t_node* A = na primeira chamada e' a raiz da arvore depois passa a ser um de seus no's
*/
void inOrder(t_node *A);

/*Funcao que faz o percurso de pos-ordem na arvore
Retorno:
	void
Parametros:
	t_node* A = na primeira chamada e' a raiz da arvore depois passa a ser um de seus no's
*/
void posOrder(t_node *A);

/*Funcao auxiliar que elimina todos os nos da arvore
Retorno:
	void
Parametros:
	t_node* A = na primeira chamada e' a raiz da arvore depois passa a ser um de seus no's
*/
void eliminateNode(t_node* A);

/*Funcao que destroi/elimina a arvore (ou seja, libera tudo que foi alocado)
Retorno:
	void
Parametros:
	t_tree* A = a propria arvore
*/
void eliminateTree(t_tree* A);