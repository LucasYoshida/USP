/*
***************************************************

	USP - ICMC
	ALG1 - 2017
	
	Trabalho 3 - Arvores Balanceadas

	Novembro - 2017

	Lucas Noriyuki Yoshida - 10262586

****************************************************
*/

#include <stdio.h>
#include <stdlib.h>
#include "trb.h"

//******************TAD TREE*************************

/*Funcao que inicializa a arvore
Retorno:
	t_tree* = a propria arvore a ser criada
Parametros:
	t_tree* A = a arvore a ser inicializada
*/
t_tree* initialize(t_tree* A){

	t_tree* new = malloc(sizeof(new));

	return new;

}

/*Funcao que serve para criar um novo no' na arvore
Retorno:
	t_node* = o novo no' da arvore
Parametros:
	int data = dado a ser colocado na arvore
*/
t_node* makeNode(int data){

	t_node* new = malloc(sizeof(new));

	if (new != NULL){
		new->link[0] = NULL;
		new->link[1] = NULL;
		new->red = 1;
		new->data = data;
	}

	return new;

}

/*Funcao auxiliar que indica se o no' e' vermelho ou nao e com isso auxilia na decisao das direcoes para as rotacoes
Retorno:
	int = 1 se e' vermelho ou 0 se e' preto
Parametros:
	t_node* A = no de uma arvore a ser verificado
*/ 
int isRed(t_node* A){

	//verificacao se e' vermelho ou nao
	if(A != NULL && A->red == 1)
		return 1;
	else
		return 0;

}

/*Funcao que faz a simples\uma vez rotacao para que a arvore esteja devidamente balanceada
Retorno:
	t_node* = o novo no' salvo que ajudou na rotacao
Parametros:
	t_node* A = no' a ser trabalhado a rotacao
	int dir = ajuda na direcao da rotacao(se e' esquerda ou direita)
*/
t_node* rotSingle(t_node* A, int dir){

	t_node* aux = A->link[!dir];

	A->link[!dir] = aux->link[dir];
	aux->link[dir] = A;

	A->red = 1;
	aux->red = 0;

	return aux;

}

/*Funcao que faz a simples\uma vez rotacao para que a arvore esteja devidamente balanceada
Retorno:
	t_node* = o novo no' salvo que ajudou na rotacao pela rotSingle
Parametros:
	t_node* A = no' a ser trabalhado a rotacao
	int dir = ajuda na direcao da rotacao(se e' esquerda ou direita, nesse caso a rotacao eh pelo menos uma vez para cada direcao) 
*/
t_node* rotDouble(t_node *A, int dir){

	A->link[!dir] = rotSingle(A->link[!dir], !dir);

	return rotSingle(A, dir);

}

/*Funcao que insere um dado na arvore e ainda faz os ajustes necessarios para deixar a mesma balanceada
Retorno:
	t_node* = o ultimo no' alocado na arvore que compoe a mesma
Parametros:
	t_node* A = na primeira chamada e' a raiz da arvore depois passa a ser um de seus no's
	int data = dado a ser colocado na arvore
*/ 
t_node* insertData(t_node* A, int data){

	//insere normalmente
	if (A == NULL)
		A = makeNode(data);

	//percorre a arvore como se fosse uma busca ate encontrar o local a ser alocado
	else if (data != A->data){

		//ajuda na direcao da insercao
		int dir = A->data < data;

		//vai na direcao definica anteriormente
		A->link[dir] = insertData(A->link[dir], data);

		//verifica se o filho e' vermelho
		if (isRed(A->link[dir])){
			//verifica se o outro filho e' vermelho (primeiro caso)
			if (isRed(A->link[!dir])){
				//pai vermelho e filhos pretos
				A->red = 1;
				A->link[0]->red = 0;
				A->link[1]->red = 0;
			}
			else{
				//segundo caso (se o neto e' vermelho)
				if (isRed(A->link[dir]->link[dir])){
					//faz uma rotacao simples
					A = rotSingle(A, !dir);
				}
				//terceiro caso (se o outro neto e' vermelho)
				else if (isRed(A->link[dir]->link[!dir])){
					//faz uma dupla rotacao
					A = rotDouble(A, !dir);
				}
			}
		}
	}

	return A;

}

/*Funcao que chama a insertData que faz a insercao, sendo esta para auxiliar pois e' repassada a raiz da arvore (que a mesma e' atualizada posteriormente)
Retorno:
	void
Parametros:
	t_tree* tree = arvore principal a ser atualizada
	int data = dado a ser incluido na arvore
*/
void insertion(t_tree* tree, int data){
    
	tree->root = insertData(tree->root, data);
	tree->root->red = 0;

}

/*Funcao que acha o sucessor de um numero que esta inserido na arvore (verificado previamente)
Retorno:
	void
Parametros:
	t_node* A = na primeira chamada e' a raiz da arvore depois passa a ser um de seus no's
	int data = dado a ser encontrado o sucessor
	int* aux = ajuda na procura do sucessor de data
	int* find = 1 se ja achou ou 0 se ainda nao achou
*/
void findSuccess(t_node* A, int data, int* aux, int* find){

	if(A != NULL){
		findSuccess(A->link[0], data, aux, find);
		*aux = A->data;
		if(*aux > data && *find == 0){
			printf("%d\n", *aux);
			*find = 1;
			return;
		}
		findSuccess(A->link[1], data, aux, find);
	}

}

/*Funcao que acha o precessor de um numero que esta inserido na arvore (verificado previamente)
Retorno:
	void
Parametros:
	t_node* A = na primeira chamada e' a raiz da arvore depois passa a ser um de seus no's
	int data = dado a ser encontrado o sucessor
	int* aux = ajuda na procura do sucessor de data
	int* find = 1 se ja achou ou 0 se ainda nao achou
*/
void findPrevious(t_node* A, int data, int* aux, int* find){

	if(A != NULL){
		findPrevious(A->link[0], data, aux, find);
		if(A->data == data && *find == 0){		
			printf("%d\n", *aux);
			*find = 1;
			return;
		}
		*aux = A->data;
		findPrevious(A->link[1], data, aux, find);
	}

}

/*Funcao que encontra o no' que contem o dado de maior valor na arvore
Retorno:
	int = o proprio numero a ser encontrado
Parametros:
	t_node* A = na primeira chamada e' a raiz da arvore depois passa a ser um de seus no's
*/
int findMax (t_node *A){

	if(A->link[1] == NULL)
		return A->data;
	else
		return findMax(A->link[1]);

}

/*Funcao que encontra o no' que contem o dado de menor valor na arvore
Retorno:
	int = o proprio numero a ser encontrado
Parametros:
	t_node* A = na primeira chamada e' a raiz da arvore depois passa a ser um de seus no's
*/
int findMin (t_node *A){

	if(A->link[0] == NULL)
		return A->data;
	else
		return findMin(A->link[0]);

}

/*Funcao que faz o percurso de pre-ordem na arvore
Retorno:
	void
Parametros:
	t_node* A = na primeira chamada e' a raiz da arvore depois passa a ser um de seus no's
*/
void preOrder(t_node *A){

	if(A != NULL){
		printf("%d ", A->data);
		preOrder(A->link[0]);
		preOrder(A->link[1]);
	}

}

/*Funcao que faz o percurso de em-ordem na arvore
Retorno:
	void
Parametros:
	t_node* A = na primeira chamada e' a raiz da arvore depois passa a ser um de seus no's
*/
void inOrder(t_node *A){

	if(A != NULL){
		inOrder(A->link[0]);
		printf("%d ", A->data);
		inOrder(A->link[1]);
	}

}

/*Funcao que faz o percurso de pos-ordem na arvore
Retorno:
	void
Parametros:
	t_node* A = na primeira chamada e' a raiz da arvore depois passa a ser um de seus no's
*/
void posOrder(t_node *A){

	if(A != NULL){
		posOrder(A->link[0]);
		posOrder(A->link[1]);
		printf("%d ", A->data);
	}

}

/*Funcao auxiliar que elimina todos os nos da arvore
Retorno:
	void
Parametros:
	t_node* A = na primeira chamada e' a raiz da arvore depois passa a ser um de seus no's
*/
void eliminateNode(t_node* A){

	if(A){
		eliminateNode(A->link[0]);
		eliminateNode(A->link[1]);
		free(A);
	}

}

/*Funcao que destroi/elimina a arvore (ou seja, libera tudo que foi alocado)
Retorno:
	void
Parametros:
	t_tree* A = a propria arvore
*/
void eliminateTree(t_tree* A){

	eliminateNode(A->root);
	free(A);

}
