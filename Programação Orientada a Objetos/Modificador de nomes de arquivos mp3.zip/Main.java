import java.io.File;
import java.io.IOException;
import java.util.Scanner;
import java.lang.*;
import java.io.*;
import java.util.Arrays;
import java.nio.file.Paths;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
        	

public class Main{

	public static void main(String[] args){

		Scanner sc1 = new Scanner(System.in);

		String diretorio;

		diretorio = sc1.next();

		File file = new File(diretorio);
		File afile[] = file.listFiles();

		int i = 0;

		String passarArq[] = new String[afile.length];

		for(int j = afile.length; i < j; i++){
			File arquivos = afile[i];
			passarArq[i] = afile[i].getName();
			long tamanho = afile[i].length();
		}

		char [][]nomeArq = new char[afile.length][];

		i = 0;

		for(int j = afile.length; i < j; i++)
			nomeArq[i] = passarArq[i].toCharArray();

		int quaisMp3[][] = new int[1000][2];

		int quantMp3 = 0;

		i = 0;

		for(int j = afile.length; i < j; i++){
		 	if(nomeArq[i][nomeArq[i].length - 1] == '3' && nomeArq[i][nomeArq[i].length - 2] == 'p' && nomeArq[i][nomeArq[i].length - 3] == 'm' && nomeArq[i][nomeArq[i].length - 4] == '.'){
				quaisMp3[quantMp3][0] = i;
				long tamanho = afile[i].length();
				quaisMp3[quantMp3][1] = (int)tamanho;
				quantMp3++;
			}
		}

		int cont, a, length;

		for(int j = 0; j < quantMp3; j++){

			cont = 0;
			length = nomeArq[quaisMp3[j][0]].length;

			while(cont < length){
				if(nomeArq[quaisMp3[j][0]][cont] == '.')
					break;
				if(Character.isDigit(nomeArq[quaisMp3[j][0]][cont]) || nomeArq[quaisMp3[j][0]][cont] == '_' || nomeArq[quaisMp3[j][0]][cont] == '-'){
					for(a = cont; a <= length - 2; a++){
						nomeArq[quaisMp3[j][0]][a] = nomeArq[quaisMp3[j][0]][a + 1];
					}
					nomeArq[quaisMp3[j][0]][length - 1] = '\0';
					length--;
					cont--;
				}
				cont++;
			}

		}

		String finalArq[] = new String[quantMp3];

		for(int b = 0; b < quantMp3; b++)
			finalArq[b] = String.copyValueOf(nomeArq[quaisMp3[b][0]]);

		int n = finalArq.length;
        for (int b = 0; b < n-1; b++){
            for (int j = 0; j < n-b-1; j++){
            	if (quaisMp3[j][1] > quaisMp3[j + 1][1]){
                    String temp = finalArq[j];
                    finalArq[j] = finalArq[j+1];
                    finalArq[j+1] = temp;
                    int temp2[] = quaisMp3[j];
                    quaisMp3[j] = quaisMp3[j+1];
                    quaisMp3[j+1] = temp2;
                }
            }
        }

        for(int b = 0; b < quantMp3; b++){
        	String number = Integer.toString(b + 1);
			char aux[] = new char[5];
			char aux2[] = new char[number.length()];
			int d = number.length() - 1;
			aux2 = number.toCharArray();
			for(int c = 3; c >= 0; c--){
				if(d < 0)
					aux[c] = '0';
				else{
					aux[c] = aux2[d];
					d--;
				}
			}
			aux[4] = '_';
			number = String.copyValueOf(aux);
			
			char aux1[] = finalArq[b].toCharArray();
			int tam = 0;
			for(int f = 0; f < finalArq[b].length(); f++){
				if(aux1[f] == '3'){
					tam = f;
					break;
				}
			}

			char resul[] = new char[tam + 1];
			for(int f = 0; f <= tam; f++)
				resul[f] = aux1[f];

			String last = String.copyValueOf(resul);
			
			
			String novoArq = diretorio + '/' + number + last;
			String velhoArq = diretorio + '/' + passarArq[quaisMp3[b][0]];
			
			File newArq = new File(novoArq);
			File oldArq = new File(velhoArq);

			oldArq.renameTo(newArq);
        	
        }

	}

}