
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author yonoriyuki
 */
public class Main {
    public static void main(String[] args){
         // TODO code application logic here
        
        Scanner sc1 = new Scanner(System.in);   
        
        int n = sc1.nextInt();
        
        boolean verify;
        
        for (int cont = 0; cont < n; cont++){
            int date = sc1.nextInt();
            int month = sc1.nextInt();
            int year = sc1.nextInt();
            Date d1 = new Date(date, month, year);
            
            d1.setDate(date);
            d1.setMonth(month);
            d1.setYear(year);

            verify = d1.verifyDate(date, month, year);    

            d1.displayDate(date, month, year, verify);
        }
    }
}
