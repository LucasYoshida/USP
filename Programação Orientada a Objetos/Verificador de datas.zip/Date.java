/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author yonoriyuki
 */
public class Date {
    
    private int month;
    private int date;
    private int year;
    
   	public Date(int month, int date, int year){
        this.month = month;
        this.date = date;
        this.year = year;
    }
    
    public int setMonth(int month){
       return this.month = month;
    }
    
    public int getMonth(){
        return month;
    }
    
    public int setDate(int date){
       return this.date = date;
    }
    
    public int getDate(){
        return date;
    }
    
    public int setYear(int year){
       return this.year = year;
    }
    
    public int getYear(){
        return year;
    }
    
    public void displayDate(int date, int month, int year, boolean verify){
        if(verify){
            System.out.printf("%d/%d/%d\n", this.date, this.month, this.year);
        }
        else{
            System.out.println("DATA INVALIDA");
        }
    }
    
    public boolean verifyDate(int date, int month, int year){
        if(this.month == 4 || this.month == 6 || this.month == 9){
            return !(this.date > 30 || this.date < 1);
        }
        else if(this.month == 2){
            return !(this.date > 28 || this.date < 1);
        }
        else if(this.month <= 12){
            return !(this.date > 31 || this.date < 1);
        }
        else{
            return false;
        }
    }
    
}
