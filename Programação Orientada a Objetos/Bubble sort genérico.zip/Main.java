import java.util.Scanner;

public class Main{

	public static void main(String[] args){

		Scanner sc1 = new Scanner(System.in);

		int n, n2;

		n = sc1.nextInt();

		Integer vetInt[] = new Integer[n];

		for(int cont = 0; cont < n; cont++)
			vetInt[cont] = sc1.nextInt();

		n2 = sc1.nextInt();

		Double vetDouble[] = new Double[n2];

		for(int cont = 0; cont < n2; cont++)
			vetDouble[cont] = sc1.nextDouble();

		n = sc1.nextInt();

		String vetString[] = new String[n];

		for(int cont = 0; cont < n; cont++)
			vetString[cont] = sc1.next();

		App<Integer> bs = new App<Integer>(vetInt);  // notice <Double> type param.
		bs.bubbleSort();
		
		App<Double> bs1 = new App<Double>(vetDouble);
		bs1.bubbleSort();

		App<String> bs2 = new App<String>(vetString);
		bs2.bubbleSort();

		for(int cont = 0; cont < vetInt.length; cont++)
			System.out.printf("%d ", vetInt[cont]);
		System.out.printf("\n");

		for(int cont = 0; cont < vetDouble.length; cont++){
			String aux = Double.toString(vetDouble[cont]);
			System.out.printf("%s ", aux);
		}
		System.out.printf("\n");

		for(int cont = 0; cont < vetString.length; cont++)
			System.out.printf("%s ", vetString[cont]);
		System.out.printf("\n");

	}

}