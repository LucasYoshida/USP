public class App<T extends Comparable<T>> {

    private T [] A;
    public App(T [] A) {
        this.A = A;
    }

    public void bubbleSort() {
        int n = this.A.length;
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (this.A[j].compareTo(this.A[j + 1]) > 0) {
                    T aux = this.A[j];
                    this.A[j] = this.A[j + 1];
                    this.A[j + 1] = aux;
                }
            }
        }
    }

}