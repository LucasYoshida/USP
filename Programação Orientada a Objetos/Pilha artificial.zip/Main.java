import java.util.Scanner;

public class Main{

	public static void main(String[] args){

		Stack pilha = new Stack(5);
		Scanner sc1 = new Scanner(System.in);
		
		char c;

		int n = sc1.nextInt();

		for(int i = 0; i < n; i++){

			c = sc1.next().charAt(0);

			if(c == 'I'){

				int num = sc1.nextInt();

				try{
					pilha.push(num);
				}
				catch(FullStackException error){
					error.getMessage("Pilha cheia!");
					break;
				}
			
			}
			else if(c == 'R'){

				try{
					pilha.pop();
				}
				catch(EmptyStackException error){
					error.getMessage("Remocao Invalida!");
					break;
				}

			}
			else{

				try{
					pilha.top();
				}
				catch(EmptyStackException error){
					error.getMessage("Operacao Invalida!");
				}

			}

		}

	}

}