class StackException extends Exception{

	protected String error;

	public StackException(String error){
		this.error = error;
	}

	public void getMessage(String error){
		System.out.println("Erro!");
	}
	
}

class FullStackException extends StackException{

	public FullStackException(String error){
		super(error);
	}

	@Override
	public void getMessage(String error){
		System.out.println("Erro!");
		System.out.println(error);
	}

}

class EmptyStackException extends StackException{

	public EmptyStackException(String error){
		super(error);
	}

	@Override
	public void getMessage(String error){
		System.out.println("Erro!");
		System.out.println(error);
	}

}