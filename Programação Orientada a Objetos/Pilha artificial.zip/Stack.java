public class Stack {

    private int[] intStack;
    private int size = 5;
    
    public Stack (int size){
        this.intStack = new int[this.size];
    }
    
    //inserir elemento sempre na cabeça
    public void push(int element) throws FullStackException{
        if (!isFull()){
            for (int i = 4; i > 0; i--){
                this.intStack[i] = this.intStack[i-1];
            }
            this.intStack[0] = element;
        }
        else{
            throw new FullStackException("Pilha cheia!");
        }
    }
    
    //remover elemento LIFO
    public void pop() throws EmptyStackException{
        if(this.intStack[0] != 0){
            for(int i = 0; i < 4; i++){
                this.intStack[i] = this.intStack[i+1];
            }
            this.intStack[4] = 0;
        }
        else{
            throw new EmptyStackException("Remocao Invalida!");
        }
    }
    
    //tamanho da pilha
    public int size() {
        return size+1;
    }
    
    //exibe o elemtno da cabeÃ§a
    public void top() throws EmptyStackException{
        if (this.intStack[0] == 0)
            throw new EmptyStackException("Operação Invalida!");
        System.out.println(this.intStack[0]);
    }
    
    //verifica se a pilha estÃ¡ cheia.
    private boolean isFull(){
        if (this.intStack[intStack.length-1] != 0)
            return true;
        return false;
    }
    
    //imprime a pilha
    public void print(){
        for(int i = 0; i <= size; i++){
            System.out.println("Objeto posiÃ§Ã£o: " + (i+1) + " - valor: " + intStack[i]);
        }
    }

}